var def_locations = 
{
		L_LocationID: {Caption: "Id", disabled: false},  
		L_Name: "Name",
		L_Description:"Description", 
		D_DepName: "Department name", 	
		L_Barcode: { Caption: "Barcode", disabled:true},
		L_Department: { Caption: "Department", disabled:true},
		updated_by: { Caption: "updated_by", disabled:true},
		updated_dt: { Caption: "updated_dt", disabled:true},
		entered_by: { Caption: "entered_by", disabled:true},
		entered_dt: { Caption: "entered_dt", disabled:true},
		address: { Caption: "address", disabled:true},
		L_IsleBay_code: { Caption: "IsleBay code", disabled:true},
		L_AddressID: { Caption: "AddressID", disabled:true},
		L_RFID: "RFID/Barcode",
		L_QRcode: { Caption: "QR code", disabled:true},
}
 
 
 
var  table_set = 
{
		mod_element: "locations_table_static",
		set_one_API_cmd: "on_update_location_by_id",
		get_one_API_cmd: 'on_get_location_by_id',
		get_all_API_cmd: 'on_get_all_locations', 
		delete_one_API_cmd: 'on_delete_location_by_id', 
		get_all_selectable_API_cmd: 'on_get_all_locations', 
		entID: 'L_LocationID',
		entName: 'L_Name',
		uiFormText: 'location',
		tableDef: def_locations,
		
		selectDlgEditHd :'Select location:',
		editDlgTitle:'Manage locations:',
		editDlgNewHd:'New location',
		editDlgEditHd:'Edit location ',
		joinTableBtns: true		
}
 
 
var Locations = new T_Constructor( table_set );

 
Locations.bulk = new TB_Constructor( {} );
 
 
 
//===============================================================================
Locations.bulk_delete = function( )
{
	var base = this;
 	var opts = {LOAD_CMD:'on_get_all_locations_db', ACTION_CMD:'on_delete_locations',  title:'Locations bulk delete: ', tableDef: this.tableDef,  AUTOLOAD:true, NO_FILE:true, cb:function(){base.refresh();}};
	this.bulk.bulk_op_form(opts);
}



//===============================================================================
Locations.import = function( id )
{
	var base = this;
 	var opts = {LOAD_CMD : 'on_get_all_locations_db', ACTION_CMD : 'on_import_locations', title:'Locations import/export: ',  tableDef: this.tableDef,  cb: function(){ base.refresh();}	};
	this.bulk.bulk_op_form(opts);
}
 

 


Locations.tableButtons = (function () {/*
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
				*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");
 
 
  
Locations.dlg_add_TableButtons = 
[
	{ text: 'Bulk delete', action: function( e, dt, node, config ){  				Locations.bulk_delete(); }},
	{ text: 'Import/export', action: function( e, dt, node, config ){	Locations.import(); }},
	{ text: 'Refresh', action: function( e, dt, node, config ){						Locations.refresh(); }},
	{ text: 'New', action: function( e, dt, node, config ){							Locations.create( undefined ); }},
	
	{ text: 'Delete', action: function( e, dt, node, config ){						Locations.delete( getSelectedRow(Locations.tab_element)[Locations.entID] ); }},
	{ text: 'Edit', action: function( e, dt, node, config ){  		var sRow = getSelectedRow(Locations.tab_element); if(!sRow) return modal_alert('No rows selected');  Locations.open(sRow); }},
];
 


 
Locations.selectTableButtons = (function () {/*
				<div class="s_ctrl_btn_cs join-right">
					<a class="s_ctrl_btn_c round-btn" onclick="Locations.refresh()"><span>Refresh</span></a>
					<a class="s_ctrl_btn_c round-btn" onclick="Locations.open( getSelectedRow('________') )"><span>Edit</span></a>
					<a class="s_ctrl_btn_c round-btn" onclick="Locations.create( undefined )"><span>New</span></a>
				</div>
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
				*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");

				
Locations.dlgForm = (function () {/*
				<div style="height:100%; padding: 1px;    margin: 0px;overflow: auto;  >
					<fieldset class="form">
					<table width="100%" class="table-form">
						<tr class="col-half"><td>Name</td><td><input id="new_location_name_box"  class="form-control" type="text"  ></input></td>
						<tr class="col-half"><td>Description</td><td><input id="new_location_desc_box"  class="form-control" type="text"  ></input></td>
						<tr class="col-third"><td>Barcode</td><td><input id="new_location_bc_box"  class="form-control" type="text"  ></input></td>
						<tr class="col-third"><td>QR code</td><td><input id="new_location_qr_box"  class="form-control" type="text"  ></input></td>
						<tr class="col-third"><td>RFID code</td><td><input id="new_location_rfid_box"  class="form-control" type="text"  ></input></td>
						<tr><td>Islebay code</td><td><input id="new_location_eb_box"  class="form-control" type="text"  ></input></td>
						<tr><td>Address</td><td><textarea id="new_location_L_Address_text_box"  class="form-control" type="text"  ></textarea></td>
					 
					</table>
					</fieldset>
					</div>	
				*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "")

				

Locations.fieldMap = 
					{ 
						L_Name: { elm_id: "new_location_name_box", value_attr: "value" },
						L_Description: { elm_id: "new_location_desc_box", value_attr: "value" },
						L_Barcode: { elm_id: "new_location_bc_box", value_attr: "value" },
						L_QRcode: { elm_id: "new_location_qr_box", value_attr: "value" },
						L_RFID: { elm_id: "new_location_rfid_box", value_attr: "value" },
						L_IsleBay_code: { elm_id: "new_location_eb_box", value_attr: "value" },	
						L_Address_text: { elm_id: "new_location_L_Address_text_box", value_attr: "value" },	
						
					}

 
 

 
