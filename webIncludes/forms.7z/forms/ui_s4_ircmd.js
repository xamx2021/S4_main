var def_IRcmd = 
{
		IR_instanceID: {Caption: "Id", disabled: false},
		IR_Name: "Label",
		IR_Description: { Caption: "Device description", disabled:false},
		IR_Data: { Caption: "Code", disabled:true},				
		TxButton: { 	Caption: "Send", 	fun: o => `<button  id=" IRbx ${o.TxButton} "  onclick="  MISO_cmd3( \'on_Send\'+document.irModID, {value:'${o.TxButton}'}, ui_button(id));">  ->>> </button>` ,			ssSort: "TxButton"		},
}

 
var  table_set= 
{		
		get_all_API_cmd: 'on_get_all_IRcmd',		
		set_one_API_cmd: 'on_update_IRcmd_by_id',
		get_one_API_cmd: 'on_get_IRcmd_by_id',		
		delete_one_API_cmd:'on_delete_IRcmd_by_id',		
		get_all_selectable_API_cmd: 'on_get_all_IRcmd',

		mod_element: "IR_table_static",		
		entID: 'IR_instanceID',
		selectDlgEditHd :'Select IR command:',
		editDlgTitle:'Manage IR command:',
		editDlgNewHd:'New IR command',
		editDlgEditHd:'Edit IR command ',
		uiFormText: 'IR command',	
		tableDef: def_IRcmd,
}  
  
var  IR_bulkNames_set = 
	{		
		get_many_BukI_cmd: 'on_get_all_IRcmd_db',
		set_many_BukI_cmd: 'on_import_IRcmd',
		del_many_BukI_cmd: 'on_delete_IRcmd',
	}
 

 
 
var IRcmd = new T_Constructor( table_set );
IRcmd.bulk = new TB_Constructor( {} );
   

IRcmd.bulk_delete = function( )
{	
	var base = this;
 	var opts = {LOAD_CMD:IR_bulkNames_set.get_many_BukI_cmd, ACTION_CMD:IR_bulkNames_set.del_many_BukI_cmd,  title:'Bulk delete: ', tableDef: this.tableDef, AUTOLOAD:true, NO_FILE:true, cb:function(){base.refresh();}};
	this.bulk.bulk_op_form(opts);
}


IRcmd.import = function( )
{
	var base = this;
 	var opts = {LOAD_CMD : IR_bulkNames_set.get_many_BukI_cmd, ACTION_CMD : IR_bulkNames_set.set_many_BukI_cmd, title:'IRcmd import/export: ', tableDef: this.tableDef, cb: function(){ base.refresh();}	};
	this.bulk.bulk_op_form(opts);
}
 


 
IRcmd.dlg_add_TableButtons = 
[
	{ text: 'Bulk delete', action: function( e, dt, node, config ){  			IRcmd.bulk_delete();			}},
	{ text: 'Import/export', action: function( e, dt, node, config ){			IRcmd.import(); 					}},
	{ text: 'Refresh', action: function( e, dt, node, config ){					IRcmd.refresh(); 					}},
	{ text: 'New', action: function( e, dt, node, config ){						IRcmd.create( undefined ); 	}},		
	{ text: 'Delete', action: function( e, dt, node, config ){					IRcmd.delete( getSelectedRow(IRcmd.tab_element)[IRcmd.entID] ); 		}},
	{ text: 'Edit', action: function( e, dt, node, config ){  						var sRow = getSelectedRow(IRcmd.tab_element); if(!sRow) return modal_alert('No rows selected');  IRcmd.open(sRow); }},
];


// Dialog IO mapping:
IRcmd.fieldMap = 
{ 
	IR_Name: { elm_id: "ir_cmd_cap_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Value must not be empty." },
	IR_Description: { elm_id: "ir_cmd_descr_box", value_attr: "value" },
	IR_Data: { elm_id: "ir_signal_data_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Signal data can not be empty." },
}					

	 
IRcmd.tableButtons = IRcmd.selectTableButtons = (function () {/*
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");
  
 
// Dialog IO form:
IRcmd.dlgForm = (function () {/*
				<fieldset class="form">
					<table width="100%" class="table-form">
						<tr class="col-quarter"><td>Command caption:</td><td><td><input id="ir_cmd_cap_box"  class="form-control" type="text"></input></td>
						<tr class="col-quarter"><td>Command description:</td><td><td><input id="ir_cmd_descr_box"  class="form-control" type="text"></input></td>						
						<tr class="col-quarter"><td><button  class="dt-button  round-btn " id="ir_code_capture_btn"	onclick= "MISO_cmd3( 'on_Capture'+document.irModID, {value:0},  function(c)
							{
								ui_button(id) ;   
								if(! c.status) return;								
								ir_signal_data_box.value = c.return_data[1]; 
								ir_impulse_count.innerText = c.return_data[0];								
							});"> Capture </button>									
						
							<button  class="dt-button  round-btn " id="ir_code_capture_btn"	onclick= "MISO_cmd3( 'on_Send'+document.irModID, {sendThisSignal:true, value:ir_signal_data_box.value },  function(c)
							{
								ui_button(id);
							});"> Test send </button>									
						</td>						
						<tr class="col-quarter"><td>Read code:</td> <td> <label id="ir_impulse_count"></label><td>													
						<tr class="col-full"><td>IR signal:</td><td><textarea id="ir_signal_data_box"  class="form-control" type="text" maxlength=300 ></textarea></td>		
					</table>		
				</fieldset>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, ""); 
  
