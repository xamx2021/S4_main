var def_TMcmd = 
{
		TM_InstanceID: {Caption: "ID", disabled: false},
		TM_Name: "Timer name",
		TM_Description: { Caption: "Description", disabled:false},				
		TM_Time: { Caption: "Time"},				
		TM_Sink: { Caption: "Sink", disabled:true},				
		TM_Code: { Caption: "Code", disabled:true},				
		TM_Enable: { Caption: "Start", disabled:false, fun: o => o.TM_Enable ? "enabled" : "disabled"},
		TM_RunOnce: { disabled:true },
		Status: { Caption: "Status", disabled:false, fun: o => o.Status ? "active" : "not active"},			
		Buttons: { 	Caption: "Event processing", 	fun: o => `<button  id=" TMbxStart ${o.Buttons} "  onclick="  MISO_cmd3( \'on_Start\'+document.timerModID, {value:'${o.Buttons}'}, ui_button(id));  TMR.refresh(); 	">  Start </button> <button  id=" TMbxStop ${o.Buttons} "  onclick= "  MISO_cmd3( \'on_Stop\'+document.timerModID, {value:'${o.Buttons}'}, ui_button(id)); TMR.refresh(); 	">  Stop </button>` 		},			//,			ssSort: "Buttons"

}

 
var  table_set= 
{		
		get_all_API_cmd: 'on_get_all_TMcmd',		
		set_one_API_cmd: 'on_update_TMcmd_by_id',
		get_one_API_cmd: 'on_get_TMcmd_by_id',		
		delete_one_API_cmd:'on_delete_TMcmd_by_id',		
		get_all_selectable_API_cmd: 'on_get_all_TMcmd',

		entID: 'TM_InstanceID',	
		
		mod_element: "TM_table_static",
		selectDlgEditHd :'Select schedule command:',
		editDlgTitle:'Manage schedule:',
		editDlgNewHd:'New schedule',
		editDlgEditHd:'Edit schedule ',
		uiFormText: 'Schedule',	
		tableDef: def_TMcmd,
}  

var TMR = new T_Constructor( table_set );

  /*
var  bulkNames_set = 
	{		
		get_many_BukI_cmd: 'on_get_all_TMcmd_db',
		set_many_BukI_cmd: 'on_import_TMcmd',
		del_many_BukI_cmd: 'on_delete_TMcmd',
	}
 

TMR.bulk = new TB_Constructor( {} );
   

TMR.bulk_delete = function( )
{	
	var base = this;
 	var opts = {LOAD_CMD:bulkNames_set.get_many_BukI_cmd, ACTION_CMD:bulkNames_set.del_many_BukI_cmd,  title:'Bulk delete: ', tableDef: this.tableDef, AUTOLOAD:true, NO_FILE:true, cb:function(){base.refresh();}};
	this.bulk.bulk_op_form(opts);
}


TMR.import = function( )
{
	var base = this;
 	var opts = {LOAD_CMD : bulkNames_set.get_many_BukI_cmd, ACTION_CMD : bulkNames_set.set_many_BukI_cmd, title:'TMcmd import/export: ', tableDef: this.tableDef, cb: function(){ base.refresh();}	};
	this.bulk.bulk_op_form(opts);
}
 
*/

 
TMR.dlg_add_TableButtons = 
[
	{ text: 'Bulk delete', action: function( e, dt, node, config ){  			TMR.bulk_delete();			}},
	{ text: 'Import/export', action: function( e, dt, node, config ){			TMR.import(); 					}},
	{ text: 'Refresh', action: function( e, dt, node, config ){					TMR.refresh(); 					}},
	{ text: 'New', action: function( e, dt, node, config ){						TMR.create( undefined ); 	}},		
	{ text: 'Delete', action: function( e, dt, node, config ){					TMR.delete( getSelectedRow(TMR.tab_element)[TMR.entID] ); 		}},
	{ text: 'Edit', action: function( e, dt, node, config ){  						var sRow = getSelectedRow(TMR.tab_element); if(!sRow) return modal_alert('No rows selected');  TMR.open(sRow); }},
];


// Dialog IO mapping:
TMR.fieldMap = 
{ 
	TM_Name: { elm_id: "at_caption_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Value must not be empty." },
	TM_Description: { elm_id: "at_description_box", value_attr: "value" },
	TM_Time: { elm_id: "at_time_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Time field can not be empty." },
	TM_Code: { elm_id: "at_code_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Code field can not be empty." },
	TM_Sink: { elm_id: "select_sink_box", value_attr: "SelectedValue", valid_if: not_empty,	invalid_msg: "Required" },	
	TM_Enable: { elm_id: "at_enable_cbox", value_attr: "checked", type: "checkbox"},
	TM_RunOnce: { elm_id: "at_run_onece_cbox", value_attr: "checked", type: "checkbox"},
}					

	 
TMR.tableButtons = TMR.selectTableButtons = (function () {/*
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");
  
  
  

// Load Drop-down select:  
TMR.onFormAfterLoadCB = function()
 {  
  						MISO_cmd3( 'on_get_list_all_modules', {top:0},  function(data)
							{					
								if( typeof(select_sink_box) === "undefined") return;							
 										
									$("#select_sink_box").empty();
									for(var i in data.return_data)
										{						
											var o = document.createElement("option");
											o.innerHTML = "";											
											o.innerHTML =  data.return_data[i].modNm;	
											o.value = data.return_data[i].modID;
											o.modActions = data.return_data[i].modActions;
											if( select_sink_box.SelectedValue === o.value  ){	o.selected = true;			}
											document.getElementById("select_sink_box").appendChild(o);	
										}
									$("#select_sink_box").change(function(a){		 var  m = a.delegateTarget[ a.delegateTarget.selectedIndex ].modActions ; if(!m)m='';		sink_method_box.innerText = m;						}); 
							}); 
 }
 
 
 
 
// Dialog IO form:
TMR.dlgForm = (function () {/*
				<fieldset class="form">
					Variables: "t","s",		
					<table width="100%" class="table-form">					
						<tr class="col-quarter"><td>Caption:</td><td><td><input id="at_caption_box"  class="form-control" type="text"></input></td>								
						<tr class="col-half"><td>Description:</td><td><td><input id="at_description_box"  class="form-control" type="text"></input></td>
						<tr class="col-full"><td>Schedule:</td><td><textarea id="at_time_box"  class="form-control" type="text" maxlength=600 ></textarea></td>						
						<tr class="col-full"><td>Code:</td><td><textarea id="at_code_box"  class="form-control" type="text" maxlength=600 ></textarea></td>						
						<tr class="col-half"><td>Sink:</td><td><select id="select_sink_box"  class="form-control" type="text"   onchange="    var e = select_sink_box; e.SelectedValue = e.options[e.selectedIndex].value;     "></select></td>

						<tr class="col-third"><td>Methods:</td><td><textarea id="sink_method_box"  class="form-control" type="text" maxlength=1000 ></textarea></td>
												
				<!--	<tr class="col-quarter"><td>						
						<button  class="dt-button  round-btn" id="at_code_test_btn"	onclick= " MISO_cmd3( 'on_Act'+document.autoModID, {sendThisSignal:true, value:at_code_box.value },  function(c)
							{
								ui_button(id);
							});"
							> Activate </button>									
						</td>						
				-->			
						
					</table>		
					
					<input type="checkbox" id="at_enable_cbox">Enable </input>					
					<input type="checkbox" id="at_run_onece_cbox">Run once</input>
					
				</fieldset>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, ""); 
  
