var def_TMcmd = 
{
		ET_InstanceID: {Caption: "ID", disabled: false},
		ET_Name: "Timer name",
		ET_Description: { Caption: "Description", disabled:false},				
		ET_ToDashBrd: { Caption: "Show at  dashboard"},				
		ET_Source: { Caption: "Sink", disabled:true},				
		//ET_Code: { Caption: "Code", disabled:true},				
		ET_Enable: { Caption: "Start", disabled:false, fun: o => o.ET_Enable ? "enabled" : "disabled"},
		//ET_RunOnce: { disabled:true },
		Status: { Caption: "Status", disabled:false, fun: o => o.Status ? "active" : "not active"},			
		Buttons: { 	Caption: "Event processing", 	fun: o => `<button  id=" EVbxStart ${o.Buttons} "  onclick="  MISO_cmd3( \'on_event_trigger\'+document.timerModID, {value:'${o.Buttons}'}, ui_button(id));   ">  Activate </button> ` 		},			//,			ssSort: "Buttons"

}

 
var  table_set= 
{		
		get_all_API_cmd: 'on_get_all_ETcmd',		
		set_one_API_cmd: 'on_update_ETcmd_by_id',
		get_one_API_cmd: 'on_get_ETcmd_by_id',		
		delete_one_API_cmd:'on_delete_ETcmd_by_id',		
		get_all_selectable_API_cmd: 'on_get_all_ETcmd',

		entID: 'ET_InstanceID',	
		
		mod_element: "ET_table_static",
		selectDlgEditHd :'Select event command:',
		editDlgTitle:'Manage event:',
		editDlgNewHd:'New event',
		editDlgEditHd:'Edit event ',
		uiFormText: 'Event',	
		tableDef: def_TMcmd,
}  

var EVT = new T_Constructor( table_set );

  /*
var  bulkNames_set = 
	{		
		get_many_BukI_cmd: 'on_get_all_TMcmd_db',
		set_many_BukI_cmd: 'on_import_TMcmd',
		del_many_BukI_cmd: 'on_delete_TMcmd',
	}
 

EVT.bulk = new TB_Constructor( {} );
   

EVT.bulk_delete = function( )
{	
	var base = this;
 	var opts = {LOAD_CMD:bulkNames_set.get_many_BukI_cmd, ACTION_CMD:bulkNames_set.del_many_BukI_cmd,  title:'Bulk delete: ', tableDef: this.tableDef, AUTOLOAD:true, NO_FILE:true, cb:function(){base.refresh();}};
	this.bulk.bulk_op_form(opts);
}


EVT.import = function( )
{
	var base = this;
 	var opts = {LOAD_CMD : bulkNames_set.get_many_BukI_cmd, ACTION_CMD : bulkNames_set.set_many_BukI_cmd, title:'TMcmd import/export: ', tableDef: this.tableDef, cb: function(){ base.refresh();}	};
	this.bulk.bulk_op_form(opts);
}
 
*/

 
EVT.dlg_add_TableButtons = 
[
	//{ text: 'Bulk delete', action: function( e, dt, node, config ){  			EVT.bulk_delete();			}},
	//{ text: 'Import/export', action: function( e, dt, node, config ){			EVT.import(); 					}},
	{ text: 'Refresh', action: function( e, dt, node, config ){					EVT.refresh(); 					}},
	{ text: 'New', action: function( e, dt, node, config ){						EVT.create( undefined ); 	}},		
	{ text: 'Delete', action: function( e, dt, node, config ){					EVT.delete( getSelectedRow(EVT.tab_element)[EVT.entID] ); 		}},
	{ text: 'Edit', action: function( e, dt, node, config ){  						var sRow = getSelectedRow(EVT.tab_element); if(!sRow) return modal_alert('No rows selected');  EVT.open(sRow); }},
];


// Dialog IO mapping:
EVT.fieldMap = 
{ 
	ET_Name: { elm_id: "at_caption_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Value must not be empty." },
	ET_Description: { elm_id: "at_description_box", value_attr: "value" },

	ET_Source: { elm_id: "select_src_box", value_attr: "SelectedValue", valid_if: not_empty,	invalid_msg: "Required" },	
	ET_Enable: { elm_id: "at_enable_cbox", value_attr: "checked", type: "checkbox"},
	ET_ToDashBrd: { elm_id: "on_dashbrd_cbox", value_attr: "checked", type: "checkbox"},
	
}

	 
EVT.tableButtons = EVT.selectTableButtons = (function () {/*
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");
  
  
  

// Load Drop-down select:  
EVT.onFormAfterLoadCB = function()
 {  
  						MISO_cmd3( 'on_get_list_all_modules', {top:0},  function(data)
							{					
								if( typeof(select_source_box) === "undefined") return; 										
									$("#select_source_box").empty();
									for(var i in data.return_data)
										{						
											var o = document.createElement("option");
											o.innerHTML = "";											
											o.innerHTML =  data.return_data[i].modNm;	
											o.value = data.return_data[i].modID;
											o.modActions = data.return_data[i].modActions;
											o.modEvents = data.return_data[i].modEvents;
											if( select_source_box.SelectedValue === o.value  ){	o.selected = true;			}
											document.getElementById("select_source_box").appendChild(o);	
										}
									$("#select_source_box").change(function(a)
										{		 
											var  m = a.delegateTarget[ a.delegateTarget.selectedIndex ].modActions; if(!m)m='';		source_method_box.innerText = m;
											var  e = a.delegateTarget[ a.delegateTarget.selectedIndex ].modEvents; if(!e)e='';		source_events_box.innerText = e;
										}); 
							}); 
 }
 
 
 
 
// Dialog IO form:
EVT.dlgForm = (function () {/*
				<fieldset class="form">
		 
					<table width="100%" class="table-form">					
						<tr class="col-quarter"><td>Caption:</td><td><td><input id="at_caption_box"  class="form-control" type="text"></input></td>								
						<tr class="col-half"><td>Description:</td><td><td><input id="at_description_box"  class="form-control" type="text"></input></td>
					 
						<tr class="col-half"><td>Source:</td><td><select id="select_source_box"  class="form-control" type="text"   onchange="    var e = select_source_box; e.SelectedValue = e.options[e.selectedIndex].value;     "></select></td>

						<tr class="col-third"><td>Methods:</td><td><textarea id="source_method_box"  class="form-control" type="text" maxlength=1000 ></textarea></td>
						<tr class="col-third"><td>Events:</td><td><textarea id="source_events_box"  class="form-control" type="text" maxlength=1000 ></textarea></td>
	
						
					</table>		
					
					<input type="checkbox" id="at_enable_cbox">Enable </input>					
					<input type="checkbox" id="on_dashbrd_cbox">Show button in dashboard</input>
					
				</fieldset>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, ""); 
  

  
$(document).on('__on_api_connected', function () {  EVT.tableInit('events_table_static').show_table();  });	