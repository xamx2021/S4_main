var def_DBL = 
{
		DBL_instanceID: {Caption: "Id", disabled: false},
		DBL_EventName: "Event",
		DBL_Datetime: { Caption: "date-time", disabled:false},

}

 
var  dbl_table_set = 
{		
		get_all_API_cmd: 'on_get_all_DBLog',		
		get_one_API_cmd: 'on_get_DBLog_by_id',				
		set_one_API_cmd: 'on_update_DBLog_by_id',	
		delete_one_API_cmd:'on_delete_DBLog_by_id',		
		
		//get_all_selectable_API_cmd: 'on_get_all_DBLog',
		
		entID: 'DBL_instanceID',
		
		mod_element: "DBLdata_table_static",		
		selectDlgEditHd :'Select :',
		editDlgTitle:'Manage :',
		editDlgNewHd:'New ',
		editDlgEditHd:'Edit  ',
		uiFormText: ' Log ',	
		tableDef: def_DBL,
}  


 var  dbl_bulkNames_set = 
	{		
		get_many_BukI_cmd: 'on_get_all_DBLog_db',
		set_many_BukI_cmd: 'on_import_DBLog',
		del_many_BukI_cmd: 'on_delete_DBLog',			
	}
 
 
 
var DBLog = new T_Constructor( dbl_table_set ); 

 
DBLog.dlg_add_TableButtons = 
[
	{ text: 'Bulk delete', action: function( e, dt, node, config ){  			DBLog.bulk_delete();			}},
	{ text: 'Import/export', action: function( e, dt, node, config ){			DBLog.import(); 					}},
	{ text: 'Refresh', action: function( e, dt, node, config ){					DBLog.refresh(); 					}},
	{ text: 'New', action: function( e, dt, node, config ){						DBLog.create( undefined ); 	}},		
	{ text: 'Delete', action: function( e, dt, node, config ){					DBLog.delete( getSelectedRow(DBLog.tab_element)[DBLog.entID] ); 		}},
	{ text: 'Edit', action: function( e, dt, node, config ){  						var sRow = getSelectedRow(DBLog.tab_element); if(!sRow) return modal_alert('No rows selected');  DBLog.open(sRow); }},
];



DBLog.bulk = new TB_Constructor( {} );
   

DBLog.bulk_delete = function( )
{	
	var base = this;
 	var opts = {LOAD_CMD:dbl_bulkNames_set.get_many_BukI_cmd, ACTION_CMD:dbl_bulkNames_set.del_many_BukI_cmd,  title:'Bulk delete: ', tableDef: this.tableDef, AUTOLOAD:true, NO_FILE:true, cb:function(){base.refresh();}};
	this.bulk.bulk_op_form(opts);
}



//===============================================================================
DBLog.import = function( id )
{
	var base = this;
 	var opts = {LOAD_CMD : 'on_get_all_DBLog', ACTION_CMD : 'on_import_locations', title:'Log import/export: ',  tableDef: this.tableDef,  cb: function(){ base.refresh();}	};
	this.bulk.bulk_op_form(opts);
}
 


// Dialog IO mapping:
DBLog.fieldMap = 
{ 
	DBL_EventName: { elm_id: "dbl_event_name_box", value_attr: "value", valid_if: not_empty,	invalid_msg: "Value must not be empty." },
	DBL_Datetime: { elm_id: "dbl_timedate_box", value_attr: "value" },	 
}					

	 
DBLog.tableButtons = DBLog.selectTableButtons = (function () {/*
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");
  
 
// Dialog IO form:
DBLog.dlgForm = (function () {/*
				<fieldset class="form">
					<table width="100%" class="table-form">
						<tr class="col-quarter"><td>Event name:</td><td><td><input id="dbl_event_name_box"  class="form-control" type="text"></input></td>
						<tr class="col-quarter"><td>Date/time:</td><td><td><input id="dbl_timedate_box"  class="form-control" type="text"></input></td>						
					 
					</table>		
				</fieldset>
*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, ""); 
  
