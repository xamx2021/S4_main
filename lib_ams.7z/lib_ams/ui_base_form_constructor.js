//=======================================================================================
//
//=======================================================================================
var validNumber = function(v){	return !(Number(isNaN(v)));  }
var not_empty = function(v){	if(v)return true;  return false; }
var anyway = function(v){	return true;  }
var int_greater_then_0 =  function(v){	if(v < 1) return false;	return true;	}
var positive = function(v){	return (	Number(v) >0 );	}
var numeral = function(v){  if( isNaN(Number(v)) ) return false; else return true;	      }

function monyeValFormat( value ){   return  Number(value).toFixed(2) }

var dateStdFormat = function (value){   try{ return (new Date(value)).toISOString().split('T')[0]; } catch(e){	return value;	}     }
//var dateStdFormat = function (value) {return null ? (new Date(value)).toISOString().split('T')[0] : ""}


function zeroPad(num, places) {  var zero = places - num.toString().length + 1;  return Array(+(zero > 0 && zero)).join("0") + num;}	

function load_dropDown_select( api_cmd, data_vl, data_id, element_name, selected_value) 					
{			
								selected_value = Number ( selected_value );

								MISO_cmd3( api_cmd, {top:0},  function(data)
									{
										if(data.error)return console.log("error #000413", data);	
										$("#" + element_name).empty();
																				
										//if(selected_value === undefined)
											{
												var tmp = {};
												tmp[ data_id ] = undefined;
												tmp[ data_vl ] = 'Not set';
												data.return_data.push(tmp);
											}
																				
										
										for( var i in data.return_data)
											{						
												var o = document.createElement("option");
												o.innerHTML = data.return_data[i][data_vl];												
												o.e_id = data.return_data[i][data_id];
												if( data.return_data[i][data_id] == selected_value ) o.selected = true;
												if(!document.getElementById(element_name)) return console.log("ERROR: field '" +element_name+ "' not found in the fonrm.");
												document.getElementById(element_name).appendChild(o);
											}											
									});
}					

 
 

//=======================================================================================
//  Server -> Client
//=======================================================================================
function fload_obj( map, input )
{
 
	for(var key in map)
		{		
			try{				
					var cfg = map[key];					
					var loaded_value = input[ key ];																		//		if(loaded_value === undefined) continue;		
					var value_format = cfg.value_format;		
					var element = document.getElementById( cfg.elm_id );							//if(element === undefined) continue;
					var value_max = cfg.value_max;
					var valid_regexp = cfg.valid_regexp;
					//var param = cfg.value_attr;																		if(param === undefined) continue;			
					var value_attr = cfg.value_attr;																	//	if(value_attr === undefined) continue;
					var def = cfg.def_tab;								
					
										
					if(value_format) loaded_value = value_format(loaded_value);
					if( def )	if(def[ loaded_value ]) loaded_value = def[ loaded_value ];
					if(value_max)	element.maxLength = value_max;
				
				if(value_max)	console.log('MAXVAL: fffffff'); 

				
					
					
					//  Use date-time picker:  NOT IMPLEMENTED
					if(cfg.type === 'checkbox')
						{
								if(loaded_value)		element.checked = true;
								else 	element.checked = false;
								continue;
						}			
						
					
					//  Use date-time picker:  NOT IMPLEMENTED
					if(cfg.type === 'date')
						{
							if(!loaded_value) continue;
							//	console.log( 'this is date picker: ' , cfg.elm_id,   '   ',  loaded_value);
								element.value =  new Date(loaded_value).toISOString().split('T')[0];
							//	element.value =  new Date(loaded_value).toISOString().split('T')[0];
							//	element.value = loaded_value;
								//	element[ value_attr ] =	new Date(loaded_value).toISOString().split('T')[0];
								//	console.log( 'this is date picker converted: ' , new Date(loaded_value).toISOString().split('T')[0]);
								continue;
						}						
					

					
					
					//  Just call "load_dropDown_select"
					if(cfg.selectLoader)
						{
								load_dropDown_select( cfg.selectLoader.cmd, cfg.selectLoader.text, cfg.selectLoader.id,  cfg.elm_id,  loaded_value);							
								continue;
						}
						
					//  Just call "load_entity_select"
				//	if(cfg.advSelectLoader)
				//		{
				//				load_entity_select( cfg.selectLoader.cmd, cfg.selectLoader.text, cfg.selectLoader.id,  cfg.elm_id,  loaded_value);							
				//				continue;
				//		}
						
						
						
						
					if(value_attr) element[ value_attr ] = loaded_value; 						
						
								
					if(valid_regexp)
						{					
							element.setAttribute("reg", valid_regexp);								//element.reg = valid_regexp;	
							// Validate loaded values:
							var res = loaded_value.match(  new RegExp( valid_regexp ) );	
							setErrorStatusCol( element, res );
							// Validate on update:
							element.onkeyup = function(o){	regex_val(this);	}						
						}							
					
		//		} catch(e){     console.log('WARNING: fload_obj: Loading field value failed:     ', cfg.elm_id, '   /   ', key, '       value: ', loaded_value);    }
				} catch(e){       console.log('WARNING: fload_ob');    }
		}
}
		
		
		
function errorBlnAtElement(e, message)
{
	var item = jQuery( e );
	//item.closest('.formHintBubble').remove();	
	//item.parent().find('.formHintBubble').remove();	
	var pos = item.position();				
	var bubble = $('<span/>').html('<span class="formHintBubble" style="left: ' + pos.left + 'px; top:' + pos.top + 'px;">' + message + '<div class="cross">X</div></span>').contents();
	bubble.insertAfter(item);
	
	$('body').on('click.formBubble', '.formHintBubble .cross', function() 
			{
               $(this).closest('.formHintBubble').remove();
            //   $('body').off('.formBubble');
			});
}
		

//=======================================================================================
// Client -> Server
//=======================================================================================
function fread2( output, map )
{

	for(var key in map)
		{			
			var element = document.getElementById( map[key].elm_id );		
			if(!element) continue;			
			var item = jQuery( element );
			item.parent().find('.formHintBubble').remove();
		}

		

	var form_valid = true;	
	for(var key in map)
		{		
					var element_valid = true;
					var cfg = map[key];				 	
					var value_format = cfg.value_format;		
					var element = document.getElementById( cfg.elm_id );							if(!element) continue;				
					var valid_regexp = cfg.valid_regexp;				
					var value = element[ cfg.value_attr ];									// Mapping				
				
				
				
					if(valid_regexp && !regex_val(element) )element_valid = false;						

					if( cfg.valid_if && !cfg.valid_if( value )  )element_valid = false;
							
								
						
						
						
						
					if( element_valid == false )						
						{		
							if(cfg.invalid_msg)	errorBlnAtElement( '#'+cfg.elm_id, cfg.invalid_msg);
								element_valid = false;
								form_valid = element_valid = false;
								value = undefined;		
								setErrorStatusCol( element, false );
						}	
					else 
						{
							setErrorStatusCol( element, true );
							$(element).parent().find('.formHintBubble').remove();
							// remove all:
					//		if(  $('.formHintBubble')[0]  )			$('.formHintBubble')[0].remove();
							
							//
						}
					
					
					
					
					
					
					
					
					

					try{				
							// 
							if(cfg.selectLoader)
									{
										output[ key ] = element.options[element.selectedIndex].e_id;
										continue;
									}									


							//   
							if(cfg.type === 'checkbox')
								{
										 if( element.checked ) var loaded_value = 1;
										else  if( element.checked === false) var loaded_value = 0;
										else var loaded_value = undefined;										
										output[ key ] = loaded_value;
										continue;
								}			
								
								
							//   
							if(cfg.type === 'date')
								{
										
										loaded_value = element.value;			// new Date(loaded_value).toISOString().split('T')[0];
										console.log( 'this is Date picker: ' , loaded_value,   '   ',  element.value);
								
										output[ key ] = loaded_value;
										continue;
								}			
								
									
									
									
							// 		
							output[ key ] = value;

						}catch (e) {		 console.log( "WARNING: fread2: missing or not loaded element ", key );			}
		}
		return form_valid;
}
		
		
		
		
		
		
		
		
		
//=======================================================================================
//
//=======================================================================================
function fload( map )
{
 

	for(var key in map)
		{
				var cfg = map[key];
				var element = document.getElementById( cfg.elm_id );
				
				if(!element ) { 	console.log('fload: Missing field >   ', cfg.elm_id  , '  /   ', key  ); continue;	}		//			if(element === undefined) continue;
																				//		if(loaded_value === undefined) continue;					
				var value_max = cfg.value_max;
				var valid_regexp = cfg.valid_regexp;
	
				if(cfg.noLocalStorage) continue;
				if(cfg.selectLoader)
						{ 
							var stored_value = localStorage.getItem( cfg.elm_id + '_' + param );
							if(stored_value ) var loaded_value = stored_value;	else  var loaded_value  = undefined;
							
							
							load_dropDown_select( cfg.selectLoader.cmd, cfg.selectLoader.text, cfg.selectLoader.id,  cfg.elm_id,  loaded_value);							
							continue;
						}
				
				
				
				var param = cfg.value_attr;
				if(param) 
					{
						var stored_value = localStorage.getItem( cfg.elm_id + '_' + param );
						if(stored_value ) element[ cfg.value_attr ] = stored_value;	 	
					}


					//if( def )	if(def[ loaded_value ]) loaded_value = def[ loaded_value ];
					if(value_max)	element.maxLength = value_max;
					
					if(valid_regexp)
						{					
							element.setAttribute("reg", valid_regexp);
							// Validate loaded values:
							//var res = loaded_value.match(  new RegExp( valid_regexp ) );	
							//setErrorStatusCol( element, res );
							// Validate on update:
							element.onkeyup = function(o){	regex_val(this);	}						
						}	
										



				
		}
}
		
//=======================================================================================
//
//=======================================================================================
function fload_one( key , map)
{
				var element = document.getElementById( map[key].elm_id );	
				if(!element ) { 	console.log('fload_one: Missing field >', map[key].elm_id  , '   /  ', key  ); return;	}	//if(element === undefined) return;
				var param = map[key].value_attr;																				if(param === undefined) return;
				var stored_value = localStorage.getItem( map[key].elm_id + '_' + param );			if(stored_value === undefined) return;
				element[ map[key].value_attr ] = stored_value;				
}
		
//=======================================================================================
//
//=======================================================================================
function fsave( map )
{ 
	for(var key in map)
		{
				var element = document.getElementById( map[key].elm_id );	
				if(!element ) { 	console.log(' Missing field >', map[key].elm_id  , '   /   ', key  ); continue;	}			
				var param = map[key].value_attr;
				if(!param) continue;				
				var value_to_store = element[ map[key].value_attr ];		if(value_to_store === undefined) continue;		
				localStorage.setItem( map[key].elm_id + '_' + param, value_to_store);
		}
}


//=======================================================================================
//
//=======================================================================================
function fhasUpdate( map )
{
	for(var key in map)
		{
				var e = document.getElementById( map[key].elm_id );									if(element === undefined) continue;
				
				if(e._updated)	{			e._updated = false; return true;			}
		}
}



		
//=======================================================================================
//
//=======================================================================================
function fread( obj, map )
{
	for(var key in map)
		{
			try{
				var element = document.getElementById( map[key].elm_id );			if(element === undefined) continue;
				var value = element[ map[key].value_attr ];			if(value === undefined) continue;
				obj[ key ] = value;
			}catch (e) {		 console.log( "Warning #frd00031: missing element ", key );			}
		}
		return obj;
}
		
		






var oType = undefined;


//=======================================================================================
//
//=======================================================================================	
function st_chk_test_devel(o, item_qty)
{
		if( item_qty <= parseInt(o.available) ) return;
			modal_alert({ title: 'Stock problem',	
				content: '<table> <tr><td><img src="/themes/images/warning.png"></img></td><td>	&nbsp;	&nbsp; </td> <td>  <font><b>' 
				+ 'This item is out of stock, expecting backorder'
				+ '</b><br></td></tr></table>',	theme: 'blue'	});										
}	
	
	
	
	
	
	
//=======================================================================================
//
//=======================================================================================
var c_constructor = function (btn_id, table_id, type, form_types)
	{
		var that = this;
		this.type = type;
		this.btn_id = btn_id;
		this.table_id = table_id;
		this.form_itemlist = [];
		this.onFormInit = form_types[type].onFormInit;
		this.onFormReload = form_types[type].onFormReload;
		this.editDlg = form_types[type].editDlg;
		this.newDlg = form_types[type].newDlg;		
		this.editRules = form_types[type].editRules;		
		if(form_types[type].bothDlg)	this.editDlg = this.newDlg = form_types[type].bothDlg;
		//this.editFieldMap = Object.assign(form_types[type].bothFieldMap, form_types[type].editFieldMap);
		//this.newFieldMap = Object.assign(form_types[type].bothFieldMap, form_types[type].newFieldMap);		
		this.editFieldMap = form_types[type].editFieldMap;
		this.newFieldMap = form_types[type].newFieldMap;
		this.edtButtons = form_types[type].edtButtons;
		this.newButtons = form_types[type].newButtons;	
		this.form_draw_item_list = form_types[type].drawList;
		this.addItem = form_types[type].addItem;
		this.form_type_name = form_types[type].form_type_name;
		this.on_delete_entity_by_id = form_types[type].on_delete_entity_by_id;
		this.on_update_entity_by_id = form_types[type].on_update_entity_by_id;
		this.on_get_entity_by_id = form_types[type].on_get_entity_by_id;
		this.on_get_all_entities = form_types[type].on_get_all_entities;
		this.on_get_partial_entities = form_types[type].on_get_partial_entities;
		var that = this;	 			
		var dialog_uid = this.table_id;			
		this.import = function (cb, prm) {    alert('not implemented.');	}		
		//    11.19.2018 		
	//	this.table_init =  function(tabDef){		MISO_cmd3(this.on_get_all_entities, { top: 0, O_type: that.type }, function (o) { create_dialog_table(o,table_id, tabDef); }); start_dialog_table_loading(table_id);			}
		


		var filter_order ={};
		function make_filter()
			{            	
				filter_order = that.filter.enable_Datatbles_RO_open_ordersfilter_chbox = ( localStorage.getItem("enable_Datatbles_RO_open_ordersfilter_chbox")   == "true" );
			}
		this.filter = { 
			O_type: that.type, 
			filter:filter_order
		};
		this.table_init =  function(tabDef){	
				make_filter();
				if (this.on_get_partial_entities)
					create_dialog_table({
						"status" : true,
						"return_data":{
								"tabData": []
						}
				},table_id, tabDef, undefined, true, {data: this.filter, api: that.on_get_partial_entities }); 
				else{
					MISO_cmd3(this.on_get_all_entities, { top: 0, O_type: that.type, filter:filter_order },function (o) { 
						create_dialog_table(o,table_id, tabDef); 
					}); 
					start_dialog_table_loading(table_id);		
				}
		}
		this.table_reload  = function(){
				make_filter();
				if (this.on_get_partial_entities)
					$('#'+table_id).dataTable().api().ajax.reload(null, false);
				else {
					start_dialog_table_loading(dialog_uid);	
					MISO_cmd3(this.on_get_all_entities, { top: 0, O_type: that.type, filter:filter_order}, function (o) {  
						update_dialog_table(o, dialog_uid); 
						stop_dialog_table_loading(dialog_uid); });  	
				};
			}
		this.btn_add_item = function (){       that.addItem(that.form_itemlist, function(){        that.form_draw_item_list(that.form_itemlist );	},  that.type )};
		this.disableForm = function(){
			this.dlg_hndl.$modalBody.find("input,select,textarea").attr("disabled", "disabled");
			this.dlg_hndl.$modalBody.find("#btn_add").hide();
			this.dlg_hndl.$modalBody.find("#btn_adf").hide();
		}
		var modeBindingTypes = {
			"String": function(rules){
				this.dlg_hndl.$modalBody.find("#" + rules).removeAttr("disabled");
			},
			"Function": function(rules){
				rules.apply(this);
			},
			"Array": function(rules){	
				for (var r in rules){
					var rule;
					if (rule = rules[r])
						modeBindingTypes[rule.constructor.name].call(this, rule);
				}
			},
		}
		this.applyEditMode = function(){
			if (this.editRulesList == null)
				return;
			var rule;
			that.disableForm();
			for (var r in this.editRulesList){
				rule = this.editRules[this.editRulesList[r]]
				if (rule)
					modeBindingTypes[rule.constructor.name].call(this, rule);
			}
		}
		this.form_reload = this.load = function() 
		{ 
			this.dlg_hndl.$modalBody.preloader().process();
			MISO_cmd3(this.on_get_entity_by_id, { id: that.id, O_type: this.type  }, function (o) 
			{ 		
				that.dlg_hndl.$modalBody.preloader().hide();	

				
				if(o.error){	 modal_error( o.msg );    return  console.log('ERROR!, ', o);		}
	
				
				
				fload_obj(that.fieldMap, o.return_data);		//**************
				try{
					that.editRulesList = o.return_data.status.profile.rules.map(r=>r.rule);
				}
				catch(e){
					that.editRulesList =  o.return_data.status ? o.return_data.status.profile ? [] : null : null;
				}
				
				if(!o.return_data)return;
				var list = o.return_data.itemList;
				that.form_itemlist = [];
				for (var i in list)    that.form_itemlist.push(list[i]);
				that.applyEditMode(that.editRulesList);
				that.form_draw_item_list(   that.form_itemlist, that.id == 0,  that.type );		
				that.form_data = o.return_data;
				if (that.attachmentList)
					that.attachmentList.val( o.return_data.attachments);

				// On form init procedure:
				// NEWWW
				if( that.onFormReload ) that.onFormReload( that );
				var dlgButtons = [{		label: 'Close',		cssClass: "dt-button round-btn danger",		action: function (d) {	that.save_l();  d.close();  }}];
				//var dlgButtons = [{		id: 'dlg_btn1',		label: 'Close',		cssClass: "dt-button round-btn danger",		action: function (d) {	that.save_l();  d.close();  }}];
				var defaultBtns = (that.defaultButtons || []).concat(dlgButtons);
				var btns = composeButtons(that.transitionButtons, that.actionButtons, defaultBtns);
				that.dlg_hndl.setButtons(btns);
				that.dlg_hndl.setTitle(that.form_type_name + ': ' +  that.id + (that.form_data.SO_BackorderFrom ? ' (backorder ' + that.form_data.SO_BackorderFrom + ')' : ''))
			});
		}


		// Save form to server:
		this.save = function (d, exit) 
		 {
			var obj = { id: this.id };
			var valid = fread2(obj, this.fieldMap);
			// handle messages:
			////////if ( !obj.id ) return modal_alert(' Error, missing user id.');
			obj.form_itemlist = this.form_itemlist;
			if(that.attachmentList)
				obj.attachments = this.attachmentList.val();
			obj.O_type = this.type;
			// Read form and validate:
			if (!valid) return;
			
			return new Promise(function(resolve, reject){
				//if (!valid) resolve();
				//if (!valid)   resolve();
				if (!valid) return reject();
				
				function do_save() 
				{
					that.save_l(); 
					MISO_cmd3(that.on_update_entity_by_id, obj, function (o) 
					{				
						//MISO_status_display(o, "Updated" );			
						if (o.error){	 modal_error( o.msg );    return  console.log('ERROR:, ', o);		}	
						that.table_reload ();
						if (obj.id != 0)
							that.form_reload ();
						if (o.error != false && !exit) that.form_reload();
						if (o.error == false && exit) d.close();
						if (!o.error && !exit)
							resolve(o);
					});
				}
				// Action confirmation  here...
				do_save(); 
			})
		}
		
		// Load form from local storage:
		this.load_l = function () {    fload(this.fieldMap); }
		
		// Save form values to local storage:
		this.save_l = function (d, exit) { fsave(this.fieldMap); }

		//this.create = function (iid, sender_elmt_ID, dialog_uid, type) 
		this.create = function (iid, sender_elmt_ID, dialog_uid, type){    this.open();	}

		// Open / create new entity:
		this.open = function (row) 
		{
	var dlg = '';
			
				// updated 11.20.18:
					var isNew = !row;	if (row) {	this.id = row.O_OrderID;		if( !this.id && row )   this.id = row[0];								}    else this.id = 0;
	
					if (isNew) 			this.fieldMap = this.newFieldMap, dlg = this.newDlg, addButtons = this.newButtons;
					else					this.fieldMap = this.editFieldMap, dlg = this.editDlg, addButtons = this.edtButtons;
					
					 
					this.isNew = isNew;
					Object.assign(this.fieldMap, form_types[type].bothFieldMap);	
					
 	
							//this.editFieldMap = Object.assign(form_types[type].bothFieldMap, form_types[type].editFieldMap);
		//this.newFieldMap = Object.assign(form_types[type].bothFieldMap, form_types[type].newFieldMap);
					
					
	//				fload_obj(that.fieldMap, o.return_data);		//**************
					
					//this.fieldMap = Object.assign(fieldMap, form_types[type].bothFieldMap);					
					oType = this.type;			
					this.form_itemlist = [];
					this.editRulesList = null;
					var dlgButtons = [
						//	{	id: 'dlg_btn1',	label: 'Close',	cssClass: "dt-button round-btn danger",		action: function (d) { that.save_l();  d.close();  }			},
							{	label: 'Close',	cssClass: "dt-button round-btn danger",		action: function (d) { that.save_l();  d.close();  }			},
							{	id: 'dlg_btn3', label: 'Save ',	cssClass: "dt-button round-btn",	action: function (d) {
									var p = that.save(d);
									if(!p)return;
									p.then(function(o){
										d.close();
										that.open(o.return_data, null, table_id, type);
									});    
								}
							},
							{	id: 'dlg_btn3',label: 'Save & Close',	cssClass: "dt-button round-btn",	action: function (d) { that.save(d, 'exit'); }			},
							];
							
					//if(isNew) var tl = 'New  ' +  this.form_type_name + ' ';		else var tl = '<input id="entity_io_box"  readonly disabled></input> ' +  this.form_type_name + ': ' +  this.id;
					if(isNew) var tl = 'New  ' +  this.form_type_name + ' ';		else var tl = this.form_type_name + ': ' +  this.id;
					
					if( row ) if( row.SO_BackorderFrom ) tl += ' (backorder ' + row.SO_BackorderFrom + ')';
					
					var dlg_hndl = BootstrapDialog.show({ title: tl, message: $(dlg), draggable: true, closeByBackdrop: false, animate: false, cssClass: 'ddd-dialog form-dialog', buttons: dlgButtons });
					dlg_hndl.entity = this;
					this.dlg_hndl = dlg_hndl;
					// load fields from local storage if new
					if(isNew)this.load_l(); 	else     this.load();   
					
					if(document.getElementById('btn_add')) document.getElementById('btn_add').onclick = this.btn_add_item;			else console.log(' oops! Button missing ',  this.btn_add_item);
				
					// On form init procedure:
					if( this.onFormInit ) this.onFormInit( this );		
			
					
// !!!!!!!!!!! Devel only: ----------------------
					this.btn_show_tks = function()
					{
						var id = that.id;
						var mod_element = "tickets_at_order_table";
						//var dlg = "<table id=\""+mod_element+"\" class=\"item-list-editor display dataTable\"  style=\"width:100%;\"></table>";
						var dlg =(function () {/*			
						<div class="dt-buttons">
							<a class="dt-button round-btn" onclick=" Ticket.open ( getSelectedRow('________'), null, '________'  );	  "><span>Edit</span></a><a class="dt-button round-btn" onclick=" Ticket.create( undefined, null, '________', 1  );	 "><span>New</span></a><a class="dt-button round-btn" onclick="OProcessor.openprocessorForm(undefined, undefined, undefined, ____type____); "><span>Generate</span></a><a class="dt-button round-btn " onclick="Ticket.delete( getSelectedRow('________')[0], null, '________'  );		 "><span>Delete</span></a>
						</div>
						
						<table id='________' class=\"item-list-editor display dataTable\"  style=\"width:100%;\"></table>
						
						*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "").replace(/________/g, mod_element);//.replace(/____id____/g, id);
						
						
						
						
			/// AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA [ debug only code ] AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
						if(type === 'S') var T_type = 1;
						if(type === 'P') var T_type = 2;
						if(type === 'Ret') var T_type = 2;
						
						dlg = dlg.replace(/____type____/g, T_type);
						dlg = dlg.replace(/____id____/g, id);
						
					//	BootstrapDialog.show({ title: 'Tickets:', message: $(dlg), draggable: true, closeByBackdrop: false, animate: false, cssClass: 'ddd-dialog', buttons: [{	id: 'dlg_btn1',	label: 'Close',	cssClass: "dt-button round-btn danger",	action: function (d){ d.close();  }}] });
						BootstrapDialog.show({ title: 'Tickets:', message: $(dlg), draggable: true, closeByBackdrop: false, animate: false, cssClass: 'ddd-dialog', buttons: [{	label: 'Close',	cssClass: "dt-button round-btn danger",	action: function (d){ d.close();  }}] });
								
						
						
						
						start_dialog_table_loading(mod_element);	
						MISO_cmd3("get_all_tickets_for_this_order" , { id: id,  top: 0 }, function (o) 
							{
								create_dialog_table(o, mod_element);
								MISO_status_display(o); 
								var ticket_count = o.return_data.length;
								$('#' + mod_element).on('dblclick', 'tr', function (o) {   Ticket.open(getSelectedRow(mod_element), null, mod_element); });
							});
					}
					
				if(document.getElementById('btn_show_tks')) document.getElementById('btn_show_tks').onclick = this.btn_show_tks;			else console.log('button btn_show_tks is not in DOM! ');
				
				// -------------------------------------
				
				$("#btn_gen_ticket").click(function(){
					var types = {'S': 1, 'P': 2, 'Ret': 2 }
					OProcessor.generateTicket(that.id, types[that.type]);
				})
				
		}
		
		
		

		// Delete
		this.delete = function ( cb ) 
		{
			var id = this.id;
			modal_confirm("Delete  selected entity  " + id + "?", function (r) {
			if (!r) return;
			MISO_cmd3(that.on_delete_entity_by_id , { id: id,  O_type:that.type }, function (o) 
				{
				   that.table_reload();
					//MISO_status_display(o, "Deleted"); 		
					MISO_status_display(o); 
					if(typeof cb === "function")cb(that.dlg_hndl);
				});
			});
		}		
		
		// Delete by id
		this.delete_by_id = function ( id ) 
		{
			modal_confirm("Delete  selected entity  " + id + "?", function (r) {
			if (!r) return;
			console.log( 'DEL1: ', id);
 
			MISO_cmd3(that.on_delete_entity_by_id , { id: id,  O_type:that.type }, function (o) 
				{
				   that.table_reload();
					//MISO_status_display(o, "Deleted"); 		
					console.log( 'DEL2: ', o);
					MISO_status_display(o); 
				});
			});
		}
	
		// PDFExport = print
		this.print = function ( id ) 
		{			
				//	 printJS('printJS-form', 'html')
		}

 
	
    }	
 
 
 