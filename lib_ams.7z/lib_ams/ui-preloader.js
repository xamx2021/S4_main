(function($){
    var preloaderHtml = `
<div class="preloader">
    <svg xmlns="http://www.w3.org/2000/svg" class="indicator wait" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" viewBox="0 0 100 100">
        <circle class="wait-circle" cx="50" cy="50" fill="none" r="49" stroke="#6bbbff" stroke-width="2" transform="rotate(48 50 50)">
            <animateTransform attributeName="transform" type="rotate" calcMode="linear" values="0 50 50;180 50 50;720 50 50" keyTimes="0;0.5;1" dur="2s" begin="0s" repeatCount="indefinite"></animateTransform>
            <animate attributeName="stroke-dasharray" calcMode="linear" values="0 314.49555921538757;314.4955592153876 -2.842170943040401e-14;0 314.49555921538757" keyTimes="0;0.5;1" dur="2" begin="0s" repeatCount="indefinite"></animate>
        </circle>
    </svg>
    <svg version="1.1" class="indicator check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" viewPort="100px 100px">
        <circle class="check-circle" fill="none" stroke="#73AF55" stroke-miterlimit="10" cx="50" cy="50" r="48">
            <!--<animate attributeName="stroke-dashoffset" fill="remove" calcMode="ease-in-out" values="314;0" keyTimes="0;1" dur="1.5s" begin="DOMNodeInsertedIntoDocument" repeatCount="1"></animate>-->
        </circle>
        <polyline class="check-check" fill="none" stroke="#73AF55" stroke-dashoffset="0" stroke-dasharray="76" stroke-width="4" stroke-miterlimit="10" points="27.8,51.5 45.5,67.8 80.2,30.2">
            <!--<animate attributeName="stroke-dashoffset" fill="remove" calcMode="ease-in-out" values="76;0" keyTimes="0;1" dur="1.5s" begin="0s" repeatCount="1"></animate>-->
        </polyline>
    </svg>
    <svg version="1.1" class="indicator fail" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
        <circle class="fail-circle" fill="none" stroke="#D06079" stroke-miterlimit="10" cx="50" cy="50" r="48" />
        <line class="fail-l-line" fill="none" stroke="#D06079" stroke-miterlimit="10" x1="25" y1="25" x2="75" y2="75" />
        <line class="fail-r-line" fill="none" stroke="#D06079" stroke-miterlimit="10" x1="75" y1="25" x2="25" y2="75" />
    </svg>
</div>`;
    $.fn.preloader = function(){
        var preloaders = [];
        $(this).each(function(){
            var el = $(this);

            var preloader = el.data("preloader-data");
            
            if (!preloader)
                el.data("preloader-data", initPreloader(el)), preloader = el.data("preloader-data");
            
            preloaders.push(preloader);
        })

        return preloaders[0];

        function initPreloader(el){
            var preloader = $(preloaderHtml);
            var t;
            el.append(preloader);
            
            function process(){
                clearTimeout(t);
                preloader.removeClass("success failed");
                preloader.addClass("shown process");
            }

            function success(timeout){
                clearTimeout(t);
                preloader.removeClass("process failed");
                preloader.addClass("shown success");

                t = setTimeout(hide, timeout);
            }
            function fail(timeout){
                clearTimeout(t);
                preloader.removeClass("process success");
                preloader.addClass("shown failed");

                t = setTimeout(hide, timeout);
            }

            function hide(){
                preloader.removeClass("process success failed shown");
            }

            return {
                process,
                success,
                fail,
                hide
            }
        }
    }
})($)