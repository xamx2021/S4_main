(function(){  
    var template = `
        <div class="role-manager">
            <div class="role-list-container">
                <div class="list-header">User roles:</div>
                <div data-role-list class="role-list"></div>
                <div class="new-role-box">
                    <input data-role-input type="text" class="new-role-name" placeholder="Enter role name" />
                    <button data-add-btn class="add-role-btn btn dt-button round-btn">+</button>
                </div>
            </div>
            <div class="permission-list-container">
                <div class="list-header">Permissions:</div>
                <div data-permissions class="permission-list">
                </div>
            </div>
        </div>
    `;
    var roleTemplate = `<div class="role"></div>`;
    var permissionTemplate = `
        <div class="permission">
            <input data-permission-sel type="checkbox"/>
            <span data-permission-name class="permission-name"></span>
        </div>
    `;
    $.fn.roleManager = function(){     
        if (this.length == 0)
            return null;
        var $el = $(this[0]);
        $el.append($(template));
        var $roleList = $el.find("[data-role-list]");
        var $roleInput = $el.find("[data-role-input]");
        var $roleAdd = $el.find("[data-add-btn]");
        var $permissionList = $el.find("[data-permissions]");
        var roles;
        var accessList;
        var selectedRole;
        Promise.all([
            loadRoles().then(data => roles = data),
            loadPermissions().then(data => accessList = data)
        ]).then(function(){
            drawRoleList();
        })

        $roleAdd.click(addRole);        

        function initRoleElement(role){
            var $role = $(roleTemplate);
            var $deleter = $("<span class='delete'></span>")
            $role.text(role.name);
            $role.append($deleter);
            $role.click(()=>selectRole($role, role));
            $deleter.click(()=>{
                modal_confirm(`Delete access role: "${role.name}"?`, (a)=>{
                    if (a)
                        isNaN(parseInt(role.id))
                            ? deleteRole() 
                            : MISO_cmd3("delete_user_role", {id: role.id}, function (o) { 
                                if( o.error == true )
                                    return MISO_status_display(o);
                                deleteRole();
                })});
            })

            if (role.changed)
                $role.addClass("changed");

            function deleteRole(){
                roles.splice(roles.indexOf(role), 1);
                $role.remove();
                if (role == selectedRole)
                    selectedRole = undefined,
                    createPermissionList(),
                    drawPermissionList($role)
            }
            return $role;
        }

        function selectRole($role, role){
            deselectRole();
            deselectRole = () => $role.removeClass("selected");
            selectedRole = role;
            $role.addClass("selected");
            createPermissionList();
            drawPermissionList($role);
        }

        function deselectRole(){};

        function createPermissionList(){
            return selectedRole ? selectedRole.access = Object.assign({}, accessList, selectedRole.access) : undefined;
        }

        function initPermissionElement(accessList, permission, $role){
            var $permission = $(permissionTemplate);
            var $chb = $permission.find("[data-permission-sel]");
            var $txt = $permission.find("[data-permission-name]");
            $txt.text(ugly_field_mapping_v00[permission]);
            $chb.prop('checked', accessList[permission]);

            $permission.click(()=>{
                var val = accessList[permission] = !accessList[permission];
                $chb.prop('checked', val);
                val ? $permission.addClass("selected") 
                    : $permission.removeClass("selected");
                selectedRole.changed = true;
                $role.addClass("changed");
            })

            return $permission;
        }

        function drawRoleList(){
            for (var r in roles)
                $roleList.append(initRoleElement(roles[r]));
        }

        function drawPermissionList($role){
            $permissionList.html('')
            if (!selectedRole) return;
            var permissions = selectedRole.access;
            for (var p in permissions)
                $permissionList.append(initPermissionElement(permissions, p, $role));
        }

        function addRole(){
            var name = $roleInput.val();
            var role;
            if (name != ""){
                role = {
                    name,
                    access: {},
                    changed: true
                };
                var $role = initRoleElement(role);
                $roleList.append($role);
                roles.push(role);
                selectRole($role, role);
                $roleInput.val('');
            }
        }

        function save(){
            var rolesToSave = roles.filter(r => r.changed == true)
                                   
            if (rolesToSave.length)
                modal_confirm(`Save changed roles?`, (a)=>{
                    if (a) MISO_cmd3("update_user_roles", rolesToSave.map(r => ({id:r.id, name:r.name, access: JSON.stringify(r.access)})), function (o) { 
                        if( o.error == true )
                            return MISO_status_display(o);
                            
                        var data = o.return_data;
                        for (var i = 0; i < data.length; i++)
                            rolesToSave[i].changed = false,
                            rolesToSave[i].id = data[i].id;                            

                        $roleList.find(".changed").removeClass("changed");                
                })});
        }
        
        return {
            $el,
            save
        }
    }

    $.fn.roleManagerModal = function(){  
        if (this.length == 0)
            return null;
        var $el = $(this[0]);
        $el.click(showManager);

        function showManager(){
            var manager = $("<div></div>").roleManager();
            var dialogCfg ={
                title: "User role manager",
                message:  manager.$el,
                cssClass: "select-dialog ddd-dialog",
				closeByBackdrop: false,
				animate: false,
                buttons: 
                [
                    {	label: 'Save', cssClass: "dt-button  round-btn",	 action: ()=>manager.save()		}, 
                    {	label: 'Close', cssClass:"dt-button danger round-btn ",	action: function(d){	d.close();	}	}
                ]
            };
            var dlg = BootstrapDialog.show(dialogCfg);	
        }
    }
    function loadRoles(){
        return new Promise(function(resolve, reject){            
            MISO_cmd3("get_user_roles", { }, function (o) { 
                if( o.error == true )
                    return reject();
                var data = o.return_data;
                for (var i in data)
                    data[i].access = JSON.parse(data[i].access);
                resolve(data);
            });
        })
    }

    function loadPermissions(){
        return new Promise(function(resolve, reject){            
            MISO_cmd3("get_all_permissions", { }, function (o) { 
                if( o.error == true )
                    return reject();
                var data = {};
                resolve(o.return_data.reduce((a,d) => (a[d.prm] = false, a), data));
            });
        })
    }

    $(document).ready(function(){
        $("[data-role-manager]").each(function(){
            $(this).roleManager();
        });
        $("[data-role-manager-modal]").each(function(){
            $(this).roleManagerModal();
        });
    })
})()