 



class T_ChartConstructor  
	{
			constructor( chartContainer, activeLegendContainer, staticCBid, CJSP )
							{
								//		T_Constructor.prototype.lastId = 0;
								//		for( var key in set) this[key] = set[key];													
								//		this.tab_element = this.getLastID();
									//	console.log( 'chart init: ',  this.tab_element  )	
								//	this.tableButtons = this.selectTableButtons = (function () {/*
								//		<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
								//	*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");				
								var r = this.init(chartContainer, activeLegendContainer, staticCBid, CJSP);
								r.draw_all_chart_data = this.draw_all_chart_data;
								r.append_chart_data = this.append_chart_data;
								r.CJSP = this.CJSP;
								r.staticCBid = staticCBid;	 
								return r;
							}
	}

	
//T_ChartConstructor.prototype.getLastID = function(){ __lastId ++;		return	'table' + __lastId;}


//==========================================================================================================
// ONE: Init	
T_ChartConstructor.prototype.init = function(chartContainer, activeLegendContainer, staticCBid, CJSP)
{			
	this.CJSP  =  CJSP;	
	var that = this;
	activeLegendContainer = document.getElementById(activeLegendContainer);
	chartContainer = document.getElementById(chartContainer);
					
				// Do not draw points in the lines:
				for(var i in CJSP) 
					{
						if(!CJSP[i].pointRadius)CJSP[i].pointRadius = 0;
					}
					
				// Active legend generator:
				// 1. Table:
				var tbl = document.createElement('table');
				tbl.style.width = '100%';
				tbl.setAttribute('border', '0');
				var tbdy = document.createElement('tbody');
				  
				// 2. Content:
				for( var i in CJSP)
					{
							CJSP[ i ].hidden = true;										// The default state							
							var tr = document.createElement('tr');
							// Checkbox:
							var checkbox = document.createElement("input");
									checkbox.type = 'checkbox';	 
									checkbox.id = staticCBid + i;															//checkbox.id = 'cbx____UnId___'+i;				// Better module-dependent ID
									//Load cb state from local storage:
									checkbox.checked = (localStorage.getItem(checkbox.id) === 'true');
									CJSP[ i ].hidden = !checkbox.checked;
									checkbox.onchange = function( i,c,cid )
										{
											// Save state:
											localStorage.setItem(cid, c.checked);
											CJSP[ i ].hidden =  !c.checked;
											if(that.chart)  that.chart.update();											
										}.bind( 0, i, checkbox, checkbox.id );											
									var td = document.createElement('td');
									td.appendChild(checkbox);
									tr.appendChild(td);
										
							// Chatr name:
							var label1 = document.createElement('label');
									label1.textContent = CJSP[i].label ;
									label1.style.color = CJSP[i].borderColor;								
									var td = document.createElement('td');
									td.appendChild(label1);
									tr.appendChild(td);
																		
							// Trend
							var label2 = document.createElement('label');
									label2.id = CJSP[i].inpDataKey + "_"+staticCBid+"_trend";
									label2.textContent = ' ';								
									var td = document.createElement('td');
									td.appendChild(label2);
									tr.appendChild(td);
																		
							// Value indicator only if 'unit' is set:
							if( CJSP[i].vunit )
								{
									var td = document.createElement('td');
									var label3 = document.createElement('label');
											//label3.id = CJSP[i].currentValueIndicatorElement	 = 'cvl____UnId___'+i;
											CJSP[i].currentValueIndicatorElement = label3;
											label3.id = 'cvl____UnId___'+i;
											label3.style["margin-left"] =  '1.5em'
											label3.style["margin-right"] =  '0.5em'
											label3.textContent = ' ';	
											//activeLegendContainer.appendChild(label3);															
											//activeLegendContainer.appendChild( 	document.createTextNode(	 CJSP[i].vunit ) 	);
											var td = document.createElement('td');
											td.appendChild(label3);
											td.appendChild(document.createTextNode(	CJSP[i].vunit ));
											tr.appendChild(td);
											
								}
							//activeLegendContainer.appendChild( document.createElement('br') );				// End of line
							tbdy.appendChild(tr);
							
							
							
					}
  
				tbl.appendChild(tbdy); 
				activeLegendContainer.appendChild(tbl)


				
				
				var y_axis_used = {};
				// Find all  y-axis and store them to y_axis:						
				for(var i in CJSP) 
					{
						if(CJSP[i].yAxisID)  y_axis_used[CJSP[i].yAxisID] = true;
					}
		
				// Add axis if used:
				var y_axis = [];				
				// Add default Y:
				if(  y_axis_used[ 'y-axis-1' ] )y_axis.push({																
																id:"y-axis-1",
																position: 'right',
																gridLines: {			zeroLineColor: 'rgba(10,55,0,1)'			},
																type: 'linear',	
																scaleLabel: {			display: false,	labelString: 'y axis 1'	},
																ticks: {	  reverse: false,	beginAtZero:false		}
															});
															
				if(  y_axis_used[ 'y-axis-2' ] )y_axis.push({
																id:"y-axis-2",
																position:'left',
																gridLines: {			zeroLineColor: 'rgba(200,55,0,1)'			},
																type: 'linear',																
																scaleLabel: {			display: false,				labelString: 'y axis 2'	},
																ticks: {	reverse: false,		beginAtZero:false	},
															});
								
				if(  y_axis_used[ 'y-axis-3' ] )y_axis.push({
																id:"y-axis-3",
																position:'left',
																gridLines: {			zeroLineColor: 'rgba(0,0,0,1)'			},
																type: 'linear',																
																scaleLabel: {			display: false,				labelString: 'y axis 2'	},
																ticks: {	reverse: false,		beginAtZero:false	},
															});
				
				

				// Chart.js initialization:
				this.chart = new window.Chart(chartContainer.getContext('2d'),
						{							 
							data: 	{					  datasets: CJSP		},
							options: 
								{
									elements: {        line: {     fill: false,     tension: 0 ,    }    		},									
									animation: {       duration: 0    												},									 
									tooltips: {			 mode: 'index',				intersect: false,		  },
									hover: {			 mode: 'nearest',		intersect: true				},
									legend: {			display: false, 		position: "right"		 	  },																			
									title: 	 {				display: false,		text: 'Air parameters'		  },									
									responsive: true,
									//maintainAspectRatio: false,
									scales: {
														xAxes: [{
															type: 'time',
															//time: {						parser:  'MM/DD/YYYY HH:mm',			tooltipFormat: 'll HH:mm'										},	// round: 'day'
															time: {						parser: 'MM/DD/YYYY HH:mm',		tooltipFormat: 'MM/DD/YY  H:m',		stepSize: 2, 	minUnit:'minute'   },	// round: 'day'
															position: 'bottom',
															gridLines: 	 {			zeroLineColor: 'rgba(10,55,0,1)'			},
															scaleLabel: {		 	display: false,					labelString: 'Time'	 },
															ticks: {			 reverse: false, 		   	maxRotation: 40,				autoSkipPadding:6, padding:12		}
														}],
														
										/*							__yAxes: [
														//	{
														//		id:"y-axis-1",
														//		position: 'right',
														//		gridLines: {			zeroLineColor: 'rgba(10,55,0,1)'			},
														//		type: 'linear',	
														//		scaleLabel: {			display: false,	labelString: 'y axis 1'	},
														//		ticks: {	  reverse: false,	beginAtZero:false		}
														//	},
												{
																id:"y-axis-2",
																position:'left',
																gridLines: {			zeroLineColor: 'rgba(200,55,0,1)'			},
																type: 'linear',																
																scaleLabel: {			display: false,				labelString: 'y axis 2'	},
																ticks: {	reverse: false,		beginAtZero:false	},
															},
															{
																id:"y-axis-3",
																position:'left',
																gridLines: {			zeroLineColor: 'rgba(0,0,0,1)'			},
																type: 'linear',																
																scaleLabel: {			display: false,				labelString: 'y axis 2'	},
																ticks: {	reverse: false,		beginAtZero:false	},
															}
													],
													*/
													yAxes : y_axis,
														
												},
									//plugins: {				zoom: {	pan: {			  enabled: true,	 mode: 'xy'			},		zoom: {			enabled: true,		mode: 'xy'		}	}					},
									plugins: {				zoom: {	pan: {			  enabled: true,	 mode: 'xy'			},		zoom: {			enabled: true,		mode: 'x'		}	}					},
								}
						});
												
return this.chart;						
}


			
//==========================================================================================================
 // TWO:  Load
//  RPC  Gets all chart_data:
T_ChartConstructor.prototype.draw_all_chart_data = function (obj)
{
						var CJSP = this.CJSP;		
										// reset datapoints:
										for(var i in CJSP) CJSP[i].data = [];
										// load new:
										for(var i in obj)
											//if(obj[i].time)
												for(var j in CJSP)
													if(  obj[i][CJSP[j].inpDataKey] )
													//	CJSP[j].data[i] = {x: obj[i].time, y: obj[i][CJSP[j].inpDataKey]};
														{
															if(obj[i].time) 
															{
																if(i == 0)CJSP[j].data[i] = {x:obj[i].time, y: obj[i][CJSP[j].inpDataKey]};
																CJSP[j].data.push(  {x: obj[i].time, y: obj[i][CJSP[j].inpDataKey]}  );
															}
														}
										this.chart.update();
}


//==========================================================================================================
//  THREE: Update
//  RPC  Gets the newest point in chart_data: This function may be combined with the UI updater (uiElementBulkUpdate)
T_ChartConstructor.prototype.append_chart_data = function (obj)
{		
						var CJSP = this.CJSP;
						var that = this;
						
										for(var j in CJSP)
													if(  isFinite(obj[CJSP[j].inpDataKey])  )
														{
														
															// Limit maximal data in the charts to 2600 points:
															if(CJSP[j].data.length >= 2600)CJSP[j].data.shift();	
														
															// Update charts which are enabled in the legend:
															CJSP[j].data.push( {x: obj.time, y: obj[CJSP[j].inpDataKey]} );

															// Show current values in the legend:
															var val = obj[ CJSP[ j ].inpDataKey ];
															var e = CJSP[ j ].currentValueIndicatorElement;
															var tf = CJSP[ j ].toFixed;
															if(val === undefined) {e.textContent =  val; continue;}
													//		if(tf &&  !isNaN(val) )	val = val.toFixed(tf);
													//		if(e &&  !isNaN(val) )  e.textContent =  val;
															
															if(tf)  val = val.toFixed(tf);
															if(e)  e.textContent =  val;						
															
															
															if(CJSP[ j ].trendMark !== undefined)
																{																
																	var trEl = document.getElementById(CJSP[ j ].inpDataKey + "_"+that.staticCBid+"_trend");																
																	//trEl.textContent = obj[CJSP[ j ].trendMark].toFixed(1);
																	if(obj[CJSP[ j ].trendMark] >0.001) trEl.textContent =  '▲';
																	else
																	if(obj[CJSP[ j ].trendMark] <0.001) trEl.textContent =  '▼';
																	else trEl.textContent =  ' ';
																	trEl.classList.add("tooltiptext");
																}

														}
										this.chart.update();
 
}

									
// FOUR: Export,  not working
// Exports data as csv or png file
/*
T_ChartConstructor.prototype.BtnDataExport = function (dataset)
								{
									console.log( 'not implemented')
									function downloadFile(data, fileName) 
										{
											var csvData = data;
											var blob = new Blob([ csvData ], {		type : "application/csv;charset=utf-8;"		});
											if (window.navigator.msSaveBlob) navigator.msSaveBlob(blob, fileName);			//ie
											else {
												var link = document.createElement("a");
												var csvUrl = URL.createObjectURL(blob);
												link.href = csvUrl;
												link.style = "visibility:hidden";
												link.download = fileName;
												document.body.appendChild(link);
												link.click();
												document.body.removeChild(link);
											}
										}

										for( var i in dataset) downloadFile(dataset[i], 'file_'+i+'.csv')

								}	
*/


	
