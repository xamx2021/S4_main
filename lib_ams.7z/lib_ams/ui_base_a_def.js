
var msgDefs =
{
	
	"Message Axxxx044": "Human readable message",
	
}