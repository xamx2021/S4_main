









	function modal_confirm(o, cb) 
		{
			if(typeof o === 'string')
			o = {title: '',	content:	 '<table> <tr><td><img src="/images/question.png"></img></td><td>	&nbsp;	&nbsp; </td> <td>  <font><b>' + o + '</b><br></td></tr></table>',	theme: 'red'	};
			
					var dlg_hndl = BootstrapDialog.show(
						{							
											title: o.title,												
											//message:   msg,							
										//	message:   '<table> <tr><td><img src="/images/question.png"></img></td><td>	&nbsp;	&nbsp; </td> <td>  <font><b>' + msg + '</b><br></td></tr></table>',								
											message:  o.content,
											draggable: true,
											closeByBackdrop: false,
											closable : false,
											animate: false,
									//		cssClass: 'ddd-dialog',	 
											close : function(){	cb(false); },
											buttons: [	
																{ label: 'Yes', id: 'dlg_btn1q', cssClass: "dt-button  round-btn ",	action:  function(d){	d.close(); cb(true); }},  
																{ label: 'No', cssClass: "dt-button  round-btn ",	action:  function(d){	d.close(); cb(false); }} 
															]
						});

				// Set size:
				dlg_hndl.$modal.find('.modal-dialog').css("width", "30%");

				setTimeout(function()
						{
							$('#dlg_btn1q').focus();
						},100);	// 25 - too short		
		}

		
		
	function modal_alert(o, cb) 
		{	
		//console.log('modal_alert O = ', o);
		
					if(typeof o === 'string')
					o = {title: '',	content: '<br><table class="bootstrap-dialog-message_selected_text"> <tr><td><img src="/images/information.png"></img> </td><td>	&nbsp;	&nbsp; </td> <td> <b>' + o + '</b><br> <b>' + '</b><br></td></tr></table>',	theme: 'red'	};
					
					if(o === undefined) return;
					if(o ==null) return;
					var dlg_hndl = BootstrapDialog.show(
						{								
											title: o.title,												
											message:   o.content,							
											draggable: true,
											closeByBackdrop: false,
											animate: false,
											cssClass: 'ddd-dialog',	             
											buttons: [{label: 'Ok',  id: 'dlg_btn1q', cssClass: "dt-button  round-btn ",	action:  function(d){	d.close(); if(cb)cb();	}}]     
						});					
								
				// Set size:
				dlg_hndl.$modal.find('.modal-dialog').css("width", "30%");			
			
				setTimeout(function()
					{
						$('#dlg_btn1q').focus();
					},100);	// 25 - too short								
		}
			
		

	function modal_error(o, cb) 
		{
					if(typeof o === 'string')
					o = {title: 'Error',	content: '<br><table class="bootstrap-dialog-message_selected_text"> <tr><td><img src="/images/error.png"></img> </td><td>	&nbsp;	&nbsp; </td> <td> <b>' + o + '</b><br> <b>' + '</b><br></td></tr></table>',	theme: 'red'	};
					
					if(o === undefined) return;
					var dlg_hndl = BootstrapDialog.show(
						{								
											title: o.title,												
											message:   o.content,							
											draggable: true,
											closeByBackdrop: false,
											animate: false,
											cssClass: 'ddd-dialog',	             
											buttons: [{label: 'Ok',  id: 'dlg_btn1q', cssClass: "dt-button  round-btn ",	action:  function(d){	d.close(); if(cb)cb();	}}]     
						});				
				
				// Set size:
				dlg_hndl.$modal.find('.modal-dialog').css("width", "30%");			
			
				setTimeout(function()
					{
						$('#dlg_btn1q').focus();
					},100);	// 25 - too short								
		}
			
	
		
	function modal_prompt(cb, o, default_value) 
		{
			var dlg= (function () {/*
				<fieldset class="form">			
					 <table class="bootstrap-dialog-message_selected_text">
						 <tr><td><img src="/images/question.png"></img> </td>
						 <td>			 &nbsp;			 &nbsp; 			 </td>
						<center>	 <tr class="col-full"><td>____p1___:</td><td><input id="value_box"  class="form-control" type="text"  value = "___p2____" ></input></td>	<center>
					 </table>			
				</fieldset>
				*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "").replace(/____p1___/g, o  )  .replace(/___p2____/g, default_value  ) ; 
				

			if(typeof o === 'string')	o = {		title: ' ',			content: dlg,				theme: 'red'	};
				if(o === undefined) return;
				var dlg_hndl = BootstrapDialog.show(
						{								
							title: o.title,												
							message:   o.content,							
							draggable: true,
							closeByBackdrop: false,
							animate: false,
							cssClass: 'ddd-dialog',	             
							buttons: 
							[
								{label: 'Ok',  id: 'dlg_btn1q', cssClass: "dt-button  round-btn ",	action:  function(d){  if(cb)cb( value_box.value ); d.close();	}},
							]    											
						});					
			
			// Set size:
			dlg_hndl.$modal.find('.modal-dialog').css("width", "30%");			
			
			// Keyboard input listener:
			$("#value_box").bind("keypress", {}, keypress);

			
			function keypress(e)
				{
					var code = (e.keyCode ? e.keyCode : e.which);
					if(code == 13) {
						e.preventDefault();
						if(cb)cb( value_box .value );					
						dlg_hndl.close();
					}
				};
									
			// Make 'Ok' default focus:
			if(0)
			setTimeout(function(){	$('#dlg_btn1q').focus();	},100);	// 25 - too short								
						
			// Make text area default focus:	
			setTimeout(function(){	$('#value_box').focus();	},100);	// 25 - too short
		}
					

			
	function modal_input_number(cb, title, default_value) 
		{
				var dlg= (function () {/*
					<fieldset class="form">			
						 <table class="bootstrap-dialog-message_selected_text">
							 <tr><td><img src="/images/number_sign.png" width="50" height="50"></img>  </td>
							 <td>			 &nbsp;			 &nbsp; 			 </td>
							<center>	 <tr class="col-full"><td>____p1___:</td><td><input id="value_box"  class="form-control" type="text"  value = "___p2____" ></input></td>	<center>
						 </table>			
					</fieldset>
					*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "").replace(/____p1___/g, title  ).replace(/___p2____/g, default_value);
				
				
				var dlg_hndl = BootstrapDialog.show(
						{								
							title: 'Number',												
							message:   dlg,							
							draggable: true,
							closeByBackdrop: false,
							animate: false,
							cssClass: 'ddd-dialog',	             
							buttons: 
							[
								{label: 'Ok',  id: 'dlg_btn1q', cssClass: "dt-button  round-btn ",	action:  function(d){  getValue() ; d.close();	}},
							]    											
						});					
			
			
				function getValue() 
				{
					var p = value_box.value;
					p = p.replace(/,/, ".");				
					p = parseInt(p);
					if( isNaN(p) ) return  modal_error('Wrong walue');					
					if(cb)cb( p );
				}				
				
				// Set size:
				dlg_hndl.$modal.find('.modal-dialog').css("width", "30%");			
				
				// Keyboard input listener:
				$("#value_box").bind("keypress", {}, keypress);
				
				function keypress(e)
					{
						var code = (e.keyCode ? e.keyCode : e.which);
						if(code == 13)
						{
							e.preventDefault();
							getValue();					
							dlg_hndl.close();
						}
					};
							
				// Make text area default focus:	
				setTimeout(function(){	$('#value_box').focus();	},100);	// 25 - too short
		}
			







//=======================
function ui_button(id, obj)
{ 
			var e = document.getElementById( id );

		 	if(typeof obj !== 'object')
				{
					//console.log('Button pressed:  id= ', id, '  o= ', obj);
					// 1. Enable progress bar animation.
					//	apiProgress.hidden = false;
					// 2. Apply default button class.

					//---- e.setAttribute('class', 'neutral_c'); 
					e.classList.remove('green_c');
					e.classList.remove('red_c');
					e.classList.remove('amber_c');
					//e.classList.add('neutral_c');
					
					return ui_button.bind(0,  id);
				}					
			else
				{
					if(obj.color)
						{

							console.log('  OLD CODE CALLEDHERE!');
							if(obj.color === 'green')e.classList.add('green_c');
							else if(obj.color === 'red')e.classList.add('red_c');
							else if(obj.color === 'amber')e.classList.add('amber_c');
							//---- setTimeout(function(){e.setAttribute('class', "neutral_c"); }, 6000);
							setTimeout(function(){						
								e.classList.remove('green_c');				e.classList.remove('red_c');			e.classList.remove('amber_c');
								//e.classList.add('neutral_c');						
								}, 8000);
						}
				
					else
						{				
							// 1. Dissable progress bar animation.
							//	apiProgress.hidden = false;	
							// 2. Apply status button class.
							if( obj.timeout ) classColor = 'amber_c';
							//--- else if( obj.error || obj.status==false || obj.status==undefined || obj.status.error) var classColor = 'red_c';
							else if( obj.error || obj.status==false || (obj.status &&obj.status.error)) var classColor = 'red_c';
							else if( obj.status ) classColor = 'green_c';												

						//	if( obj.error === undefined && obj.status === undefined ) var classColor = 'neutral_c';
							
							if( obj.status && obj.status.det )  console.log( "msg #8812: ", obj.status.det )

							e.classList.remove('green_c');
							e.classList.remove('red_c');
							e.classList.remove('amber_c');
							e.classList.add(classColor);
							setTimeout(function(){				e.classList.remove(classColor);			}, 8000);			
						}
					

					// 3. Show messages:
					//if(obj.error || obj.status==false || obj.status==undefined  )create_balloonAtElementId(id, obj.msg);
					//create_balloonAtElementId(id, obj.msg);
				}
}



var outerWrapper;


//=======================
function compUdp_oninput (id)	
						{
							// 1. update indicator
							var e =  document.getElementById(id);
							var indicator = e.getAttribute('indicator');

							function tt_Init(e)
							{
								if(outerWrapper) return;
								outerWrapper              = document.createElement('span');
								var inpHeight = 20;
								outerWrapper.style.height = inpHeight + "px";
							}

							var setValue = function(range, rangeV)
							{
								//range = document.getElementById('range'),
								rangeV = document.getElementById('rangeV');
								const      newValue = Number( (range.value - range.min) * 100 / (range.max - range.min) ),     newPosition = 10 - (newValue * 0.2);
								rangeV.innerHTML = `<span>${range.value}</span>`;
								rangeV.style.left = `calc(${newValue}% + (${newPosition}px))`;
							};
														 
							
							tt_Init(e);
							setValue (e, indicator);

							// Add/Remove classname utility functions
							var addClass = function(e,c) {
								if(new RegExp("(^|\\s)" + c + "(\\s|$)").test(e.className)) { return; };
								e.className += ( e.className ? " " : "" ) + c;
							};

							var removeClass = function(e,c) {
								e.className = !c ? "" : e.className.replace(new RegExp("(^|\\s)" + c + "(\\s|$)"), " ").replace(/^\s\s*/, '').replace(/\s\s*$/, '');
							};


							addClass(outerWrapper, 'fd-slider-active');
							addClass(outerWrapper, 'fd-slider-focused');

							e.parentNode.insertBefore(outerWrapper, e);
						}
						
						
//=======================
function compUdp_onchange (id)	
						{												
							var data = {};
							var e =  document.getElementById(id);													//console.log('on onchange' , id);
							// 2. send value to server:
							var APIcmd = e.getAttribute('command');
							var APIparam = e.getAttribute('parameter');						

							var APIobject = e.getAttribute('sendObject');
							if(APIobject) data = APIobject;

							if(!APIparam)data = e.value; 
							else data[APIparam] = e.value;

							MISO_cmd3(APIcmd, data, function(ret)
									{
										// 3. update indicator with server's response:
										//document.getElementById( e.getAttribute('indicator') ).innerText = serversValue;	e.value = serversValue;
										// 3.1. API feedback:
										ui_button(id, ret);
										// 4. show error bubble:
		//								if(!ret.status && ret.msg) create_balloonAtElementId_new(id, ret.msg);
									});			
						}





						



//========================= 4 devel ============================
//=======================
function create_balloonAtElementId_new(id, text)
					{	 
	return;
							if( ! document.getElementById("bubbleID")  )  $('<div id="bubbleID" ></div>').appendTo('body');
							   $("#bubbleID").dialog({
									width: 'auto', 	//	'min-height': 'auto',
								 	keyboard: true,		backdrop: 'enable', 				// modal: true, 
									clickOutside: true, // clicking outside the
									title:  'Error occurred:' ,
									//buttons: [{       text: "Ok",    click: function() {       $( this ).dialog( "close" );     }   }],
									position: { my: "left+" + $('#'+id).width()    + "px", of: '#'+id 	},
								}).html(    text   ) .css( "background","lightgrey").css( "opacity","0.90").css("overflow: auto;");
					}




/*
			


function create_balloonAtElementId(id,text)
{
	if( ! document.getElementById("bubbleID")  )  $('<div id="bubbleID" ></div>').appendTo('body');
				   $("#bubbleID").dialog({
						width: 'auto', //'100px',
						'min-height': 'auto',
					//	backdrop: 'static', 
						keyboard: true,
						clickOutside: true, // clicking outside the
		 				title:  'Error occurred:' ,
					 //	buttons: [{       text: "Ok",    click: function() {       $( this ).dialog( "close" );     }   }],
						position: { my: "left+10  bottom", of: '#'+id 	},
					// }).css("font-size", "15px").css( "background","grey").css( "opacity","0.95");	//	}).css("overflow: auto;").next(".ui-widget-overlay");
					}).html(    text   ).css("font-size", "15px").css( "background","lightgrey") ;	//	}).css("overflow: auto;").next(".ui-widget-overlay");

					//$("#bubbleID").css( "opacity","1.35");
	
					$(".ui-dialog-title").css("font-size", "13px").css("width", "auto").css("height", "14px");
				//	$(".ui-widget-content").css( "opacity","0.35");
			
}*/

/*
function create_balloonAtElementId(id,text)
{
	if( ! document.getElementById("bubbleID")  )  $('<div id="bubbleID" ></div>').appendTo('body');
				   $("#bubbleID").dialog({
						//width: 'auto', //'100px',
						width: '300px',
					//	'min-height': 'auto',
					//	backdrop: 'static', 
						backdrop: 'enable', 
						keyboard: true,
						clickOutside: true, // clicking outside the
		 				//title:  'Error occurred:' ,
					 //	buttons: [{       text: "Ok",    click: function() {       $( this ).dialog( "close" );     }   }],
						position: { my: "left+10  bottom", of: '#'+id 	},
					// }).css("font-size", "15px").css( "background","grey").css( "opacity","0.95");	//	}).css("overflow: auto;").next(".ui-widget-overlay");
					}).html(    text   ).css("font-size", "15px").css( "background","lightgrey") ;	//	}).css("overflow: auto;").next(".ui-widget-overlay");

					//$("#bubbleID").css( "opacity","1.35");
	
		//			$(".ui-dialog-title").css("font-size", "13px").css("width", "auto").css("height", "14px");
				//	$(".ui-widget-content").css( "opacity","0.35");
			
}




*/
