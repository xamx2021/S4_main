

					
					// Nested object flattening:
					function flatObject( obj )
					{
						for ( var k in obj.return_data.tabData ) for( var j in obj.return_data.tabData[k] )
							if(typeof obj.return_data.tabData[k][j] === 'object')
								for( var l in obj.return_data.tabData[k][j] )
									obj.return_data.tabData[k][l] = obj.return_data.tabData[k][j][l];
						return obj;
					}
					
					
//=======================================================================================
//
//=======================================================================================
class T_Constructor  
	{
			constructor( set )
							{
								T_Constructor.prototype.lastId = 0;
								for( var key in set) this[key] = set[key];
								//for( var key in this.prototype) this[key] = this.prototype[key];

								//if(!this.uiFormText) this.uiFormText = '';		
								
								this.tab_element = this.getLastID();
							//	console.log( 'table init: ',  this.tab_element  )
							
							
							this.tableButtons = this.selectTableButtons = (function () {/*
								<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>
							*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "");
				
				
							}
	}

var __lastId = 0;

T_Constructor.prototype.getLastID = function(){ __lastId ++;		return	'table' + __lastId;}


//T_Constructor.prototype.getLastID = function(){ T_Constructor.prototype.lastId = ++T_Constructor.prototype.lastId % 1000;		return	'modal' + T_Constructor.prototype.lastId;}
T_Constructor.prototype.lastID = function(){T_Constructor.prototype.lastId = T_Constructor.prototype.lastId % 1000;		return	'modal' + T_Constructor.prototype.lastId; }



//===============================================================================
T_Constructor.prototype.tableInit = function( btn_hdr_element )
{
	var that = this;
	
	// Init an element for tables:
//	this.tab_element = this.getLastID();
	//this.tab_element = 
	
	// Insert buttons:
	document.getElementById( btn_hdr_element ).innerHTML = this.tableButtons.replace(/________/g, this.tab_element  );
	
  
	$(document).on('__on_api_connected', function (o, data){   that.show_table();  });

	return this;
}

 
// $('#'+this.tab_element).selectable_table 

//===============================================================================
//T_Constructor.prototype.refresh = function(){    console.log(document.getElementById(this.tab_element).selectable_table  ); if(  document.getElementById(this.tab_element).selectable_table )	show_select_table();	else  this.show_table(); }
T_Constructor.prototype.refresh = function(){    this.show_table(); 	}



//===============================================================================
T_Constructor.prototype.show_table = function (prm) 
{
		var base = this;
		
	//	console.log( "PRM = ", prm );
		

		var API_prm = {};
		if( prm && prm.API_prm ) var API_prm = prm.API_prm;  
				
		
		
		var el = this.tab_element ? this.tab_element : undefined;
		if (this.serverSide)
			this.makeDataTableWData({
				tab_element: el || prm.tab_element,
				select_by_col: false,
				select: false,
				row_dblclick: function (obj){	
					var colname = 'ggg';
					base.open(obj.row_data, obj.col, colname);
				},
				//fake
				error: false,
				status: true,
				return_data: {
					tabData: [this.serverSide.fakeRow.all]
				}
			});
		else{
			start_dialog_table_loading(el);
			MISO_cmd3(base.get_all_API_cmd, API_prm, function (obj) {
				stop_dialog_table_loading(el);
				if (!obj.return_data)
					return base.makeDataTableWData({});
				// Nested object flattening:
				flatObject(obj);

				if (prm && prm.tab_element)
					obj.tab_element = prm.tab_element;
				else
					obj.tab_element = base.tab_element;			//		base.lastID();					
				obj.select_by_col = false;
				obj.select = false;
				obj.row_dblclick = function (obj) {
		//			console.log('ooobjj> ', obj);
					var colname = 'ggg';
					base.open(obj.row_data, obj.col, colname);
				}
				base.makeDataTableWData(obj);
			});
		}
}


//===============================================================================
T_Constructor.prototype.show_select_table = function (prm) 
{
		var base = this;
		if( base.filter ) prm.filter = base.filter;
		if (this.serverSide)
			this.makeDataTableWData({
				tab_element: prm.tab_element,
				select_by_col: false,
				select: true,
				filter: prm.filter,
				row_dblclick: function (obj){									
					prm.cb(  obj.row_data  );
				},
				//fake
				error: false,
				status: true,
				return_data: {
					tabData: [this.serverSide.fakeRow.select]
				}
			});
		else{
			start_dialog_table_loading(prm.tab_element);
			MISO_cmd3(base.get_all_selectable_API_cmd, prm.filter, function (obj) {
				stop_dialog_table_loading(prm.tab_element);
				if (prm && prm.tab_element)
					obj.tab_element = prm.tab_element;
				else obj.tab_element = base.tab_element;
				obj.select_by_col = false;
				obj.select = true;
				obj.row_dblclick = function (obj) {
					prm.cb(obj.row_data);
				}
				base.makeDataTableWData(obj);
			});
		}
}



//===============================================================================
T_Constructor.prototype.makeDataTableWData = function(obj)
{
						var base = this;
						//var element = this.tab_element;
						var element = obj.tab_element;
						var tableData  = obj.return_data;
												
						// On error -> show error message:
						if( !obj.status || obj.error )
							{
								//	modal_alert( 'Error in ' + base.get_all_API_cmd);							
								if(obj.timeout) document.getElementById(element).innerHTML = 'API Timeout';
								else if(obj.msg)
									{						
										if( msgDefs[obj.msg] ) document.getElementById(element).innerHTML = msgDefs[obj.msg]; 
										else document.getElementById(element).innerHTML = obj.msg;
									}
								return;
							}
 
			//		if(tableData.tabData.length == 0) { document.getElementById(element).innerHTML += '+No data available in table';		return;		}
/*
					if(tableData.tabData.length == 0)
						{
							tableData.tabData = [
								{
									PD_Name:'hhhhhhhhhhhhhh',
									M_BuyPrice:43,
									M_SellPrice:43,		
									M_StdPrice:86,
									M_UnitPrice:null,
									PD_Barcode:"",
									PD_ContainedItems:1,
									PD_Description:"",
									PD_LinkURL:"",
									PD_Manufacturer_PartNO:null,
									PD_Name:"30% Acrylamide/Bis Solution, 37.5:1, 500 ml",
									PD_ProductGroup:null,
									PD_ProductID:"00000050021",
									PD_Supplier_PartNO:"1610158",
									SP_SupplierID:"00000000023",
									SP_SupplierName:"BIORAD"
							}]

						}
*/

					obj.tabData = obj.tabCols = null;
					
			//		if(typeof obj.msg === 'object' && obj.msg && obj.msg.nested_object)	
			//				[ obj.tabData, obj.tabCols ] = base.proc_1( tableData, this.tableDef );					
			//		else 	[ obj.tabData, obj.tabCols ] = base.proc_2( tableData, this.tableDef );
					
					[ obj.tabData, obj.tabCols ] = base.proc_2( tableData, this.tableDef );
							

 
					if(!$.fn.dataTable.isDataTable($('#'+element)))	this.table = this.create_table_n4(obj);						
					else base.update_table(tableData);
}
 



// import related function
//===============================================================================
T_Constructor.prototype.proc_4 = function( row_data, tableDef )
{	 	
		var tabHeadder = Object.keys( row_data.tabData[0] );		
		var tabCols = [];
		for(var i in tabHeadder)
				{
						var tmpCol = {};
						var tde = tableDef[ tabHeadder[i] ];
						if(!tde)  tde = tabHeadder[i];						// TDE not found, using a key for naming a col.
						if(typeof tde === "object")tmpCol.sTitle = tde.Caption;		
						else tmpCol.sTitle = tde;							
						tmpCol.render = function( key, data, type, row, meta ){	return row[ key ];		}.bind(0, tabHeadder[i]);
						tabCols.push( tmpCol );
				}

return [ row_data.tabData, tabCols ]; 
}	




// undef devel:
//===============================================================================
T_Constructor.prototype.proc_3 = function( row_data, tableDef )
{
	// Formatting the title bar:
		var cols = [];
		var tabHeadder = Object.keys( tableDef );
		for(var i in tabHeadder)  
			{	
				cols[i] = {}; 				
				var h = tableDef[ tabHeadder[i]  ];		
			
				if(h instanceof Object)
				{
					cols[i].title = h.title;
					cols[i].getVal = h.value;
					cols[i].className = h.cssClass;
				}
				else cols[i].Caption = h;
				
		  	 	cols[i].render = function( i,a,b,c,d )
					{
					//  if(obj.return_data.columns_link && obj.return_data.columns_link[i] ){	if( a && a != true) 	return('<a href = "'+ a +'" > link </a>');		}
					//	if(link_s && link_s[i] ){	if( a && a != true) 	return('<a href = "'+ link_s +'" > link </a>');		}
					//	if(link_s && link_s[i] ){	if( a && a != true) 	return('<button style="width:100%" href = "'+ a +'" title = "'+ a +'" onclick = "linkAtNewTab(this)">Product webpage</button>');		}
						if(a !== true)
							if(cols[i].getVal instanceof Function)
								try { 		return cols[i].getVal(c); 	} 	catch(e){		return '';		}
						else return a;
					}.bind(0,i);
			}
return [ row_data.tabData, cols]; 
}




//===============================================================================
T_Constructor.prototype.proc_2 = function( row_data, tableDef, forceHiddenFields )
{	 		

		if(!tableDef) return console.log('ERROR: tableDef isn\'t defined');

		var tabHeadder = Object.keys( tableDef );


		// Empty table:
		//if(!row_data.tabData ||
		if(	row_data.tabData.length == 0) return	[[],[{sTitle: "", render: function(){return '' }}]];

		var actual_tabHeadder = Object.keys( row_data.tabData[0] );		
		
		// Check if all definitions exist:		
		var def_errors = actual_tabHeadder.filter( function (value) {  if( tabHeadder.indexOf(value)	!== -1) return false;  return true;		}  );
		if( def_errors.length )   console.log("WARNING: Missing definitions: ", def_errors,  "  api => ", this.get_all_API_cmd);
				
		// Show received data only:
		tabHeadder = tabHeadder.filter( function (value) {  if( actual_tabHeadder.indexOf(value)	== -1) return false;  return true;		}  );

		var tabCols = [];
		for (var i in tabHeadder) {
			var tmpCol = {};
			var tde = tableDef[tabHeadder[i]];
			var stdFun = function (key, data, type, row, meta) { return row[key]; }.bind(0, tabHeadder[i]);
			if (typeof tde === "object") {
				if (!forceHiddenFields && tde.disabled) continue;
				tmpCol.sTitle = tde.Caption;
				tmpCol.ssSort = tde.ssSort;
				tmpCol.render = tde.fun ? function (fun, data, type, row, meta) { return fun(row); }.bind(0, tde.fun) : stdFun;
			}
			else {
				tmpCol.sTitle = tde;
				tmpCol.ssSort = tde;
				tmpCol.render = stdFun;
			}

			tabCols.push(tmpCol);
		}
				

//if( tabCols.length != row_data.tabData.length ) return console.log(' ERROR: tabDef does not match tabData' );	
//if( tabCols.length != row_data.tabData.length ) console.log(' ERROR: tabDef does not match tabData' );	
// if( tabCols.length != row_data.tabData.length ) console.log(' ERROR: tabDef does not match tabData: Data=', row_data.tabData, ' Headder=',  tabCols);	

	
return [ row_data.tabData, tabCols ]; 
}	




//===============================================================================
T_Constructor.prototype.proc_1 = function( row_data, tableDef )
{
	// Formatting the title bar:
		var cols = [];	for(var i = 0; i<tableDef.length; i++)  
			{	
				cols[i] = {}; 				
				var h = tableDef[i];			 
				if(h instanceof Object)
				{
					cols[i].title = h.title;
					cols[i].getVal = h.value;
					cols[i].className = h.cssClass;
				}
				else cols[i].title = h;
				
		  	 	cols[i].render = function( i,a,b,c,d )
					{
					//  if(obj.return_data.columns_link && obj.return_data.columns_link[i] ){	if( a && a != true) 	return('<a href = "'+ a +'" > link </a>');		}
					//	if(link_s && link_s[i] ){	if( a && a != true) 	return('<a href = "'+ link_s +'" > link </a>');		}
					//	if(link_s && link_s[i] ){	if( a && a != true) 	return('<button style="width:100%" href = "'+ a +'" title = "'+ a +'" onclick = "linkAtNewTab(this)">Product webpage</button>');		}
						if(a !== true)
							if(cols[i].getVal instanceof Function)
								try { 		return cols[i].getVal(c); 	} 	catch(e){		return '';		}
						else return a;
					}.bind(0,i);
			}
return [ row_data.tabData, cols ]; 
}



//===============================================================================
T_Constructor.prototype.create_table_n4 = function(obj)
{	
	if(!obj.tab_element) console.log( "ERROR: Wrong table element")
	var base = this;
	var element = '#'+obj.tab_element;
	var serverRequestTimer;
	var serverSide = this.serverSide;
	var mode = obj.select ? "select": "all";
	var tconf = {
								data: obj.tabData,
								columns: obj.tabCols,								
								dom: 'C<"clear">Blfrtip',
								//sDom: 'l<"H"Rf>t<"F"ip>' ,			// Filter
								//order: [[0, 'asc']],
							//	buttons: [ 'pageLength',   'colvis',  'print',  'copy' , 	{ extend: 'csv', text: 'Export (text)' }	],
							//	buttons: [ 'pageLength',   'colvis',  'print',  'copy' 	],
								buttons: [ 'pageLength', 'colvis', 
							//		  { extend: 'copy', text: 'Clipboard' } 
									],
								select: {            style: 'single'        },
							//	responsive: true,
							//responsive: {     details: {      type: 'column',         target: 2,    orthogonal: 'responsive'  }   },
							
								stateSave: true,
								stateSaveCallback: function(settings,data){ localStorage.setItem( 'DataTables_' + settings.sInstance, JSON.stringify(data) )},
								stateLoadCallback: function(settings){return JSON.parse( localStorage.getItem( 'DataTables_' + settings.sInstance ) )		},
								//aLengthMenu: [	[5, 10, 20, 50, 100, 200, 1000, -1],	[5, 10, 20, 50, 100, 200, 1000, 'All']	],		 
								aLengthMenu: [	[ 25, 50, 100, 200, 1000, -1],	[ 25, 50, 100, 200, 1000, 'All']	],		 
								sPaginationType: 'full_numbers',								
								bLengthChange: false,									//	Hide/Show entries selector						
							 //	bAutoWidth: false,
							 	bAutoWidth: true,
							//	autoWidth: false,
								autoWidth: true,
								fnDrawCallback: function () 
								{
                                    if (this.closest('.table-horizontal-scroller').length == 0) 
									{	
                                        this.find('th').each(function (){        this.innerHTML = "<span class='transparent'>" + this.innerHTML + '</span><div data-text="' + this.innerHTML + '"><span></span></div>';             });
                                        var hScroll = $('<div class="table-horizontal-scroller"></div>');
                                        var separator = $('<div class="table-scroll-separator"></div>');
                                        var vScroll = $('<div class="table-vertical-scroller"></div>');
                                        hScroll.insertBefore(this);
										this.appendTo(vScroll.appendTo(separator.appendTo(hScroll)));
                                    }									
                                    $(element + '_filter label input').focus();									// To make the searchbox focused.
                                },
								searchDelay: 150,
								serverSide: !!serverSide,
								ajax: !!serverSide ? function(data, callback, settings){
									clearTimeout(serverRequestTimer);
									start_dialog_table_loading(obj.tab_element);	
									serverRequestTimer = setTimeout(function(){
										var draw = data.draw;
										var toSend = Object.assign({}, serverSide.data, obj.filter, {
											start:  data.start,
											length: data.length,
											search: data.search.value,
											sort:{
												column: data.order[0] ? settings.aoColumns[data.order[0].column].ssSort : undefined,
												direction: data.order[0] ? data.order[0].dir : undefined
											}
										});
										MISO_cmd3(serverSide.api[mode], toSend,function (o) {
											stop_dialog_table_loading(obj.tab_element);	
											o.return_data.draw = draw;
											callback(o.return_data);
										});
									}, 300); 
								} : undefined
						};
						

		// If multiple selection enabled:					  
		if( obj.select_by_col )
			{
				cols.unshift( {title: "Select"} );
				for(var i in obj.tabData){	obj.tabData[i].unshift( '' );			}
				 tconf.columnDefs = [ {			orderable: false,		className: 'select-checkbox',		targets:   0		} ];	// Select a row with checkbox
				 tconf.select = {            style: 'multiple'   , 	selector: 'td:first-child'     };
			}
									  
					  
		// If enabled				
		//if(     localStorage.getItem("stock_enable_r_understock_paint")  === 'true' ) 
	//	tconf.fnRowCallback = tconf.fnRowCallback_disabled;

	

	//	Show button set:	(Bad code!)
	if( obj.select )
//		if(this.select_dlg_add_TableButtons)
		tconf.buttons = tconf.buttons.concat(this.select_dlg_add_TableButtons);	
	else
		//if(this.dlg_add_TableButtons)
		tconf.buttons = tconf.buttons.concat(this.dlg_add_TableButtons);	

	
//					var dlg_hndl = BootstrapDialog.show( 	Object.assign(dialogCfg, base.stdDialogCfg)  );

	
	
		var table = $(element).DataTable( tconf );//.rowGrouping({ iGroupingColumnIndex: 2 });;		//.columnFilter(filterconf).bind('sortEnd', function(sorter){	});		
		$(element+'_filter label input').focus();										// To make the searchbox focused.
		var active_area = $(element +' tbody');
		if( obj.select_by_col )
			{	
				var table = $(element).DataTable( tconf );
			}
		else	
		// On row select event handler LMB CLC and LMB DBLCLC:		
		active_area.on( 'click dblclick', 'tr', function (evt)	
		   { 		
				if ( $(this).hasClass('selected') )$(this).removeClass('selected'); 	else 
					{
						table.$('tr.selected').removeClass('selected');
						$(this).addClass('selected');					
						table.$('tbody').css({'user-select': 'none'});					
						$(this).css({'user-select': 'text'});								
						$(element).data('lastSelectedRow',  table.row( this ).data() );							// pass event to handler
						$(element).data('lastSelectedRow_Head',  obj.tabHeadder );							// pass event to handler
					}				
			});		
			 
					 
			if(obj.row_dblclick)$(element).on('dblclick',  'tbody td', function()
				{					
 
					obj.row_dblclick(
						{
							col:	this._DT_CellIndex.column,				//this.cellIndex,
							row:	this._DT_CellIndex.row,					//this.parentNode.rowIndex,
							row_data:  table.row( this ).data()
							// col. name here
						});					
				});

		//	if(obj.row_click)	$(element).on('click',  'tbody td', function()
		//		{
		//			obj.row_click(this.innerText);					
		//		});	
 
return table;
}



//T_Constructor.prototype.create_table = T_Constructor.prototype.create_table_n4;



//===============================================================================
T_Constructor.prototype.update_table = function (obj)
{	
	if( !this.table ) return console.log('ERROR: table is not initialized.');
	if (this.serverSide)
		this.table.ajax.reload(null, false);
	else{
		this.table.clear();	
		for( var i in obj.tabData){		this.table.row.add( obj.tabData[i] );	   	};		
		this.table.draw();
	}
}


//===============================================================================
// CONFIG, default :
//===============================================================================
T_Constructor.prototype.stdDialogCfg = {	draggable: true,	closeByBackdrop: false,	animate: false,	cssClass: 'ddd-dialog',	}












/// FORMS:
//------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------
 



 
//------------------------------------------------------------------------------------------------------------------------------------
T_Constructor.prototype.select_proc = function ( row)
{
		return (row);
}
 

//------------------------------------------------------------------------------------------------------------------------------------
T_Constructor.prototype.select = function(cb, prm_filter)				//Suppliers.select = function(cb, prm_filter)
{
			if(!prm_filter)prm_filter={};
			var base = this;	
//console.log('select ' , prm_filter);			
			
			// generate new for modal dialog
			var tab_element = this.getLastID();
		
//		var tab_element = this.tab_element;
			
			 		if(prm_filter)	base.filter = prm_filter;
 
 		
			var dialogCfg =
					{
						title: base.selectDlgEditHd ,
						message:  this.selectTableButtons.replace(/________/g, tab_element ),
						cssClass: "select-dialog ddd-dialog" + (this.joinTableBtns ? " join-table-btns" : ""),
						buttons: 
						[
							{	label: 'Close', cssClass:"dt-button danger round-btn ",	action: function(d){	d.close();	}	},
							{	label: 'Select', cssClass: "dt-button  round-btn",	 action: onSelect		}, 
							{	label: 'Create', cssClass: "dt-button  round-btn",	 action: createNewAndSelect		}, 
						]
					};
			var dlg_hndl = BootstrapDialog.show( Object.assign({}, this.stdDialogCfg, dialogCfg) );			
			this.show_select_table( {tab_element:tab_element, filter:prm_filter, cb:onSelect } ); 			
		
		
		// $('#'+tab_element).selectable_table = true;
		// document[ tab_element ].selectable_table = true;
		 document.getElementById(tab_element).selectable_table = true;
		
		
		function onSelect(row) 
		{			
			// on select by BTN :: DBLCLK
			if(row && (!row[ base.entID]) && tab_element)
				row = $('#'+tab_element).DataTable().rows('.selected').data()[0];
		
			// Insert ID & Value :
			if( base.entID ) row.id = row.value = row[ base.entID ];
			if( base.entName ) row.value = row[ base.entName ];

			
			// if( typeof cb === "function" )		cb( row );
			if( typeof cb === "function" )		cb( base.select_proc( row ) )
			dlg_hndl.close();	
		}

		function createNewAndSelect(){
			base.open(null, function(data){
				if( base.entID ) data.id = data.value = data[ base.entID ];
				if( base.entName ) data.value = data[ base.entName ];
				cb(base.select_proc(data));
				dlg_hndl.close();	
			})
		}
}



//------------------------------------------------------------------------------------------------------------------------------------
T_Constructor.prototype.edit_modal = function( prm )
{

			//var tab_element = this.getLastID();
			var tab_element = this.tab_element;

			console.log('dbg: #4512, using element ', tab_element)

			var dialogCfg =
					{
						title: this.editDlgTitle,
						message:  this.tableButtons.replace(/________/g, tab_element ),
						//buttons: [{ id: 'dlg_btn1',  label: 'Close', cssClass:"dt-button danger round-btn ",	action: function(d){	d.close();	}	}]
						buttons: [{  label: 'Close', cssClass:"dt-button danger round-btn ",	action: function(d){	d.close();	}	}]
					};
			var dlg_hndl = BootstrapDialog.show( 	Object.assign(dialogCfg, this.stdDialogCfg)  );
			
			this.show_table({tab_element:tab_element, API_prm: prm}); 
}



//===============================================================================
T_Constructor.prototype.open = function( prm, saveCb )
{
				var base = this;
				var callCb = false;
				//if(prm)var id = prm.SP_RoleID;				
				if(prm)var id = prm[base.entID];			
				
				var dlg = base.dlgForm; 
				var fieldMap = base.fieldMap;					
					
				// Load form from local storage:
				var this_load_l = function(){			fload( fieldMap );			if(base.onFormAfterLoadCB) base.onFormAfterLoadCB();	if(base.onFormBeforeLoadCB) 	base.onFormBeforeLoadCB();	 	}				
				
				// Load form from server:
				var this_load = function()
					{
						//if(id)
						MISO_cmd3(base.get_one_API_cmd,  {id:id, [base.entID]:id}, function (o)
							{							
								if(o.error) return console.log('ERROR!, ',o);
								fload_obj(fieldMap,  o.return_data);
								if(base.onFormAfterLoadCB) base.onFormAfterLoadCB();			   // Call something in the form, e.g. drop-down select initialization. Calls after form data
								if ((saveCb instanceof Function) && callCb)
									saveCb(o.return_data), callCb = false;
							});
							
							if(base.onFormBeforeLoadCB) 	base.onFormBeforeLoadCB();			// Call something in the form, e.g. drop-down select initialization. Calls before form data

					}

 
					
			var this_save = function(close)
					{
						// Read form and validate:
						var obj = {id:id, [base.entID]:id};
						var valid = fread2( obj, fieldMap );
						if( !valid ) return console.log('ERROR: form validation failed');
						fsave( fieldMap );
						if(!id) close = true;				// Close new-form if saved
						
						if( prm && prm.create_wo_vrf ) obj.create_wo_vrf = true;
						
						function do_save()
							{	
								if( !base.set_one_API_cmd ) return console.log( 'ERROR: base.set_one_API_cmd undefined' );
								MISO_cmd3(base.set_one_API_cmd, obj, function (ret)
									{
										if( ret.error == true )return modal_alert( ret.msg );
										callCb = true;
										id = id || ret.return_data.insertId || ret.return_data[base.entID];
										if(id)this_load();
										fsave( fieldMap );
										if( close == true )dlg_hndl.close();
										modal_alert ( ret.msg );
										base.refresh();
									});
							}							
						modal_confirm("Save changes ?", function(r){		if(!r)return; do_save(); 		});	 
					}

		 
				if(!id) var tl = base.editDlgNewHd; else var tl = base.editDlgEditHd + ' ' +  id;											
				var dialogCfg = 
					{	
						title: tl,
						message: dlg,
						cssClass: 'ddd-dialog form-dialog',
						// default buttons:
						buttons: 
							[
							//	{ label: 'Reset to default', cssClass: "dt-button ddd-back-close round-btn", action: this_load },
			//					{ label: 'Close', cssClass: "dt-button ddd-back-close round-btn", action: function(d){ fsave( fieldMap );	 d.close();  	} },
								{ label: 'Save', cssClass: "dt-button round-btn", action: this_save},
								//{ label: 'Save&Close', cssClass: "dt-button round-btn", action: function(d){this_save(true);}  },
								{ label: 'Delete', cssClass: "dt-button round-btn", action: function(d){base.delete( id, function(){d.close(); } );} },								
								{ label: 'Clear fields', cssClass: "dt-button round-btn", action: function(d){     base.clearForm( id, function(){d.close(); } );} },
								
								{ label: 'Close', cssClass:"dt-button danger round-btn ",	action: function(d){	d.close();	}	}
							]
					}


					if(this.dlg_add_buttons)dialogCfg.buttons = dialogCfg.buttons.concat(this.dlg_add_buttons);
					
					var dlg_hndl = BootstrapDialog.show( 	Object.assign({}, base.stdDialogCfg, dialogCfg)  );

					// Pass intity ID which is used by button handlers:
					dlg_hndl[base.entID] = id;
					dlg_hndl.entity_id = id;

					if( !id ) return this_load_l();
					else this_load();
}


//------------------------------------------------------------------------------------------------------------------------------------
//Suppliers.create = function(){			this.open( null );		}
T_Constructor.prototype.create = function(){	this.open( null );		}


//===============================================================================
T_Constructor.prototype.delete = function( id, cb )
{
	var base = this;
	if( ! base.delete_one_API_cmd) return console.log("ERROR: delete_one_API_cmd is not defined.");
	modal_confirm("Delete "+ base.uiFormText +" "+ id + "?", 
		function(r){
			if(r)MISO_cmd3( base.delete_one_API_cmd, {id:id, [base.entID]:id}, function(o)
				{
					if(o.error) return modal_error( o.msg );
					base.refresh();
					if (cb instanceof Function)
						cb();
				} );		
			});
}


//===============================================================================
T_Constructor.prototype.clearForm = function( id )
{		
		for (var i in this.fieldMap) 			
				document.getElementById( this.fieldMap[i].elm_id ).value = '';
}



