


//=======================================================================================
//
//=======================================================================================
class TB_Constructor  
	{
			constructor( set )
							{
								for( var key in set) this[key] = set[key];
								for( var key in this.prototype) this[key] = set[key];							
							}
	}
	

 

TB_Constructor.prototype.refresh = function(  ){ this.show_table(); } 

 

 
 
 
 
 
//===============================================================================
// Update tag table update_dialog_table_for_bulk_op
//===============================================================================
TB_Constructor.prototype.update_dialog_table_for_bulk_op = function (obj, element)
{
		//start_dialog_table_loading(element);
		
		var obj_data = obj.return_data.tabData;
		var tabData = [];
		for(var i in obj_data)
				{				
						var tmp_data = Object.values( obj_data[ i ] );
						// Add two columns: 
						tmp_data.unshift("  ");
						tmp_data.unshift( i );
						tabData.push( tmp_data );
				}

		if( !this.table ) return console.log('ERROR: table is not initialized.');
		this.table.clear();	
		for( var i in tabData){		this.table.row.add( tabData[i] );	   	};
		this.table.draw();
			
			
//	return;	
//		var dialog =  obj.return_data.tabData;		
//		var table = $('#'+element).dataTable();
//		if(! table.fnSettings()) {	console.log('*problem x81, no data-table to update*');	 return;	}
//		oSettings = table.fnSettings();				
//		table.fnClearTable(this);																					// Clear the table
//		for(var i in dialog)	table.oApi._fnAddData( oSettings, dialog[i] );
//		table.fnDraw();																								// Re-populate the table		
		
}

 
 

//===============================================================================
// create_dialog_table_for_bulk_op
//===============================================================================
TB_Constructor.prototype.create_dialog_table_for_bulk_op = function(obj, element, onRowDraw, tableDef)
{
		//start_dialog_table_loading(element);		
		
		// On error -> show error message
		if( !obj.status || obj.error ){		document.getElementById(element).innerHTML = obj.msg;  return;		}
		
		var row_data = obj.return_data;
		if( !row_data)return console.log("ERROR: No data provided."); 
		
	//	if( obj.file_mode ){		var tabData = row_data.tabData;		var tabCols = row_data.tabHeadder;	}
	//	else 
	//	{
			var tabCols = [];		var tabData = [];
			[ tabData, tabCols ] = T_Constructor.prototype.proc_4( row_data, tableDef);
		//	[ tabData, tabCols ] = T_Constructor.prototype.proc_2( row_data, tableDef, 'nofilter' );
			var tmp = [];	
			for(var i in tabData){		var a = [];	 Object.keys(tabData[i]).forEach(function (key){		a.push( tabData[i][key]  );		});	tmp.push( a );		}
			var tabData = tmp;
			var tmp = [];	
			for(var i in tabCols)tmp.push( tabCols[i].sTitle );
			var tabCols = tmp;
	//	}			
			
		
		// Add two columns:
		tabCols.unshift( "Status" );
		tabCols.unshift( "Line" );		
	 	for(var i in tabData){	tabData[i].unshift("  ");			tabData[i].unshift( i );			}
		
		// Convert to object:
		var tmp = [];	for(var i in tabCols)  tmp[i] = { sTitle : tabCols[i] };		tabCols = tmp;	
		
		tabCols[1].render = function(a,b,c,d ){
			var val = a.toString().toLowerCase();
			if (val == "  ") 
				return a;
			var success = val == 'ok';
			return `<span title = "${a}" class="status ${success ? "success" : "error"}">${success ? "✔" : "×"}</span>`
		}

	//	if( tabCols.length != tabData[0].length ) return modal_error(' ERROR: tabDef does not match tabData' );
	//if( tabCols.length != tabData[0].length )  console.log('WARNING: tabDef does not match tabData' );
							
		var tconf = {
								dom: 'C<"clear">Blfrtip',
							//	responsive: {     details: {      type: 'column',         target: 2,    orthogonal: 'responsive'  }   },
								select: {            style: 'multiple'   , 	selector: 'td:first-child'     },
							//	select: {            style: 'multiple'   , 	selector: 'tr'   },
								stateSave: true,																																	// Save sorting and pagination states
						//		stateSaveCallback: function(settings,data){ localStorage.setItem( 'DataTables_' + settings.sInstance, JSON.stringify(data) )},
						//		stateLoadCallback: function(settings){return JSON.parse( localStorage.getItem( 'DataTables_' + settings.sInstance ) )		},
								data: tabData,							// ACHTUNG! data as it is. including menus and active elements!
								columns: tabCols,
								aLengthMenu: [	[20, 50, 100, 200, 1000, -1],	[20, 50, 100, 200, 1000, 'All']	],
								sPaginationType: 'full_numbers',   																										//   full_numbers || two_button
							 	bAutoWidth: false,
								autoWidth: true,
								bLengthChange: false,
								//		colReorder: true,
								colReorder: false,
								columnDefs: [ {			orderable: false,		className: 'select-checkbox',		targets:   0		} ],			// Select a row with checkbox
				//				sScrollX: "101%",
				//				sScrollXInner: "200%",
				//				bScrollCollapse: true,
								order: [[ 1, 'asc' ]],
								buttons: [				
							//		'pageLength', 'colvis', 'print',  'copy',  'selectAll',     'selectNone',	//	'excel'	,		//'pageLength', 'colvis',  'csv', 'print',  'copy',  'selectAll',     'selectNone',
									'pageLength', 'colvis', 'selectAll',     'selectNone',	//	'excel'	,		//'pageLength', 'colvis',  'csv', 'print',  'copy',  'selectAll',     'selectNone',
							//		{
							//				extend: 'excel',
							//				title: 'Test Data export',
							//				exportOptions: {		columns: "thead th:not(.noExport)"	, 	rows: { selected: true }	}
							//		},							
						/*			{
										extend: 'excel',
										filename: 'file_name',
										text: 'Export excel',
										//bSelectedOnly: true,
										//SelectedOnly: true,
										exportOptions: {			rows: { selected: true }		},
										customize: function (csv) 																		// Remove col 1, 2
											{
											   var split_csv = csv.split("\n"); 															// Split the csv to get the rows
												for( var index in split_csv)
													{
															var csv_row = split_csv[ index ];
															var csv_cell_array = csv_row.split('","');								// Split on quotes and comma to get each cell
															csv_cell_array.splice(0, 2);						
															csv_cell_array_quotes = '"' + csv_cell_array.join('","') ;			// Join the table on the quotes and comma; add back the quotes at the beginning and end
													 		split_csv[index] = csv_cell_array_quotes;
													}
												return split_csv.join("\n");
											} 
									   },
					*/				   {
										extend: 'csv',
										filename: 'export_70',
										text: 'Export csv',
										//bSelectedOnly: true,
										//SelectedOnly: true,
										exportOptions: {			rows: { selected: true }		},
										customize: function (csv) 																		// Remove col 1, 2
											{
											   var split_csv = csv.split("\n"); 															// Split the csv to get the rows
												for( var index in split_csv)
													{
															var csv_row = split_csv[ index ];
														//	if( !csv_row) continue;
															var csv_cell_array = csv_row.split('","');								// Split on quotes and comma to get each cell
															csv_cell_array.splice(0, 2);						
															csv_cell_array_quotes = '"' + csv_cell_array.join('","') ;	// Join the table on the quotes and comma; add back the quotes at the beginning and end
														//	csv_cell_array_quotes = '"' + csv_cell_array.join('","') + '"';	// Join the table on the quotes and comma; add back the quotes at the beginning and end
															split_csv[index] = csv_cell_array_quotes;
													}
												return split_csv.join("\n");
											} 
									   },
								//	{	text: 'Add',	name: 'add'    },
								//	{	extend: 'selected', text: 'Edit',	name: 'edit'  		},
									],									
								fnDrawCallback: function () 
								{
                                    if (this.closest('.table-horizontal-scroller').length == 0) 
									{	
                                        this.find('th').each(function (){        this.innerHTML = this.innerHTML + '<div data-text="' + this.innerHTML + '"><span></span></div>';             });
                                        var hScroll = $('<div class="table-horizontal-scroller"></div>');
                                        var separator = $('<div class="table-scroll-separator"></div>');
                                        var vScroll = $('<div class="table-vertical-scroller"></div>');
                                        hScroll.insertBefore(this);
										this.appendTo(vScroll.appendTo(separator.appendTo(hScroll)));
                                    }									
                                    $(element + '_filter label input').focus();									// To make the searchbox focused.
                                } ,
							
									
									
						};

 		var active_area = $('#'+element +' tbody');		
		var table = $('#'+element).DataTable( tconf );

		$('div.dataTables_filter input').focus();


 
		function myCallbackFunction (updatedCell, updatedRow, oldValue) {
			console.log("The new value for the cell is: " + updatedCell.data());
			console.log("The old value for that cell was: " + oldValue);
			console.log("The values for each cell in that row are: " + updatedRow.data());
		}
		
		function destroyTable() {
			if ($.fn.DataTable.isDataTable('#myAdvancedTable')) {
				table.destroy();
				table.MakeCellsEditable("destroy");
			}
		}
		
		
		
	// Do not edit col 1 & 2:
	var col_edt_end = [];
	for( var i = 3;  i < tabCols.length; ++i)col_edt_end.push(i);	
	
	
	//if(0)
	
	table.MakeCellsEditable({
							"onUpdate": myCallbackFunction,
							"inputCss":'my-input-class',
							"columns": col_edt_end,			//	[0,1,2,3],
						//	"allowNulls": {/		"columns": [3],			"errorClass": 'error'		},
							"confirmationButton": { "confirmCss": 'my-confirm-class',	"cancelCss": 'my-cancel-class'	},// could also be true
					/*		"inputTypes": 
							[
								{		"column": 0,	"type": "text",		"options": null	},
								{
									"column":1, 
									"type": "list",
									"options":[
										{ "value": "1", "display": "Beaty" },
										{ "value": "2", "display": "Doe" },
										{ "value": "3", "display": "Dirt" }
									]
								},
								{
									"column": 2,
									"type": "datepicker", // requires jQuery UI: http://http://jqueryui.com/download/
									"options": {"icon": "http://jqueryui.com/resources/demos/datepicker/images/calendar.gif"}
								}
								 // Nothing specified for column 3 so it will default to text								
							]		
					*/
						});
						
						
						
		this.table = table;
		
		stop_dialog_table_loading(element);
}
	
	

	
	
	
	


TB_Constructor.prototype.bulk_op_form = function(opts)
{
 		//var mod_element = this.mod_element;//+10000001;
 		var mod_element = '0x00000001ffffff720f';
		var id = opts.id;
		var base = this;
		var dlg = (function () {/*
				<table id="________" class=" display" cellspacing="0" width="100%" style="height:150%; padding: 1px;  margin: 0px;overflow: auto"></table>  
				<input type="file" id="file-input" hidden/>
				*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1].replace(/\r\n/g, "").replace(/________/g, mod_element);
				
				
				
		var sub_opt_create_date_nested_table_updated_items = function (obj)
		{
				if(!$.fn.dataTable.isDataTable($('#'+mod_element))) base.create_dialog_table_for_bulk_op(obj, mod_element, null, opts.tableDef);
				else {		$('#'+mod_element).DataTable().clear().draw();		base.update_dialog_table_for_bulk_op( obj, mod_element );		}
		}		
				
				
				
		var this_load_db = function()
			{		
				start_dialog_table_loading(mod_element)	
				MISO_cmd3( opts.LOAD_CMD, {top:0}, function(obj){		sub_opt_create_date_nested_table_updated_items(obj);	stop_dialog_table_loading(mod_element);	});
				if(typeof(bulk_import_f_file)!=="undefined"){	bulk_import_f_file.disabled = true;				bulk_import_f_file.style.visibility = 'hidden';		}
				if(typeof(bulk_import_f_db)!=="undefined"){	bulk_import_f_db.disabled = true;				bulk_import_f_db.style.visibility = 'hidden';		}
			}
				
				
 
				
		var buttons = 
							[
												{  id:"bulk_import_f_db", label: 'Export from DB', cssClass:"dt-button round-btn ",	action: this_load_db },	
							
												{   label: 'Invert selection', cssClass:"dt-button    round-btn ",	type:"file", action: function(d)
													{
														if(!$.fn.dataTable.isDataTable($('#'+mod_element))) return;
														var table = $('#'+mod_element).DataTable();	
														var rows = table.rows( { selected: true } )[0] ;  //gets array of selected row numbers
														table.rows().select();
														table.rows(rows).deselect();													
													}	},
													
												{   label: 'Remove selected rows', cssClass:"dt-button    round-btn ",	action: function(d)
													{														
														if(!$.fn.dataTable.isDataTable($('#'+mod_element))) return;
														var table = $('#'+mod_element).DataTable();	
														var n = table.rows('.selected').count();
														for (var i =0; i<n;++i)		table.row('.selected').remove().draw( false );
													}	
												},																						
												{   label: 'Close', cssClass:"dt-button danger round-btn ",	action: function(d){	d.close();	}	},
																						
												{   label: 'SUBMIT', cssClass: "dt-button  btn-warning", action: function importLine(d)
													{
														if(!$.fn.dataTable.isDataTable($('#'+mod_element))) return;
														var table = $('#'+mod_element).DataTable();
														var sselectedRowData = table.rows({ selected: true }).data();																						
														var tmp = [];	for (var i in sselectedRowData.toArray())  tmp.push( sselectedRowData[i] );			// convert table data
														if(sselectedRowData.length == 0) return alert(" Error, no rows senected");
														// Sends table to the core and get feedback:
														MISO_cmd3( opts.ACTION_CMD, {id:id, tabData: tmp	}, function(o)
																{ 																	
																		MISO_status_display(o);
																		if(o.error) return;
																		// Update dialog table with new data:
																		table.clear().draw();
																		var newData =o.return_data.tabData;
																		for(var i in newData)	table.row.add( newData[i] );
																		// Re-populate the table:
																		table.draw();
																//		 Assets.table_reload();
																//		 Products.table_reload();	
																		//if(opts.cb) {   opts.cb();	 console.log(' callbacvk ');	}					// update other tables in here.
																		if(opts.cb)    opts.cb();					// update other tables in here.
																});
														}
												}	
							]	
					
				if( ! opts.NO_FILE) buttons.unshift(   {  id:"bulk_import_f_file",  label: 'Import from file', cssClass:"dt-button    round-btn ",	type:"file", action: function(d)
				{
					// $('#'+mod_element).DataTable().destroy();						
						$('#file-input').click();
						bulk_import_f_file.disabled = true;
						bulk_import_f_file.style.visibility = 'hidden';						
						bulk_import_f_db.disabled = true;
						bulk_import_f_db.style.visibility = 'hidden';
				}	}  );
										

			//	var table1111 = $('#'+mod_element).DataTable();	 					 
				var dlg_hndl = BootstrapDialog.show( 
					{																						
											title: opts.title,								
											message: dlg,							
											draggable: true,
											closeByBackdrop: false,
											animate: false,
											cssClass: 'ddd-dialog',
											buttons: buttons,
					});
					
					$('.modal').css({
						width: 'auto',
						//'margin-left': function () {	   return -($(this).width() / 1.52);			},
						'margin-left': function () {	   return -400			},
						'margin-right': function () {	   return -200		}
					  });			

			//		  $('.modal-lg').css({
			//			width: function () {	   return '900px!important'	},
		//				margin: function () {	   return '0 auto'	},
		//			});
					
				// Auto load content:
				if(opts.AUTOLOAD) this_load_db();										
										
										
								 
										
										
										
				function readSingleFile(e) 
							{
									  var file = e.target.files[0];
									  if (!file) {			return console.log(' no file selected' , e.target.files);	  }
									  var reader = new FileReader();
									  reader.onload = function(e) 
									  {
											var contents = e.target.result.split('\n');											
											var obj = {};
											obj.status = true;
											var tabData = [];
											var tabHdr = [];
											
											for(var i in contents)
													{
														if( contents[i].length <=1) continue;				// Skip empty lines
														var row =	$.csv.toArray( contents[i] );		// Parse CSV
														if(i==0) {   tabHdr = row;  continue; }			// Get table header
														var tmp = {};
														for( var ri in tabHdr )tmp[ tabHdr[ri] ] = row[ri];
														tabData.push(tmp);
														
														// Check format:
														//if(row.length != tabHdr.length) console.log("ERROR: Bad import file format");														
													}
											

											obj.return_data = {tabData};
							
											sub_opt_create_date_nested_table_updated_items(obj);
									  };
									  reader.readAsText(file,"CP1251");
							}
									
									
			 
				document.getElementById('file-input').addEventListener('change', readSingleFile, false);			 

}
 



 
 