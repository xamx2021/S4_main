
function MISO_status_display(obj, ok_message, id )
{
		if( obj.error || obj.status==false || obj.timeout == true )
			{			
			
			if(  msgDefs[obj.msg] ) obj.msg = msgDefs[obj.msg];
				console.log("Cmd: " + obj.cmd  + "   \nStatus: "+obj.status   +  " \nMessage: " + obj.msg);				
				if( obj.timeout == true) modal_alert({ title: 'Timeout',	content: '<table> <tr><td><img src="/images/warning.png"></img></td><td>	&nbsp;	&nbsp; </td> <td>  <font><b>' +obj.cmd  + '</b><br></td></tr></table>',	theme: 'blue'	});
				else modal_alert("Cmd: " + obj.cmd + "  \nStatus: "+obj.status   +  "\n\rMessage: " + obj.msg);				
			}
			
		//if( obj.error || obj.status==false || obj.timeout == true )console.log("Event: " + obj.ack_event_name  + "   Status: "+obj.status   +  " Message: " + obj.msg);
		//if( obj.error || obj.status==false || obj.timeout == true )console.log(obj);
		if( obj.error || obj.status==false || obj.timeout == true ) return false; 
		//else {	 console.log(obj.ack_event_name + " OK!");	return true;}
	//	else {	 console.log(obj.ack_event_name + " OK!"); if(ok_message)modal_alert(ok_message); 	return true;}
		else { if(ok_message)modal_alert(ok_message); 	return true;}
		
		if(! id ) return;
		var e = document.getElementById( id );																
		if( obj.error || obj.status==false ) obj.color = 'red';
		else if( obj.timeout ) obj.color = 'amber';
		else obj.color = 'green'; 
		e.setAttribute('class', obj.color);			
}

