
/// 0. Create dialog form.
/// 1. If asset_ID === undefined -> creating new asset -> use default values from server and populate the dialog form.
/// 2. Else -> get asset data by ID from server and populate the dialog form.
/// 3. On 'OK' button -> send the form data to the wsocket.
/// Не закрывать после успешного завершени процедуры, сохраняет все ранее введённые значения для упрощения создания множества однотипных объекров.

// 		To make windows custom width 
			//var style = document.createElement('style'); 
			//style.innerHTML = "div.modal-dialog {  width: 50%;   }	";
			// document.getElementsByTagName('head')[0].appendChild(style);			
			
		
		
$.fn.dataTable.ext.errMode = 'none';			/// DEBUGGING, DISABLE WARNING MESSAGES!
		
var testt;
		
		
function linkAtNewTab( that )
{
	var url = that.attributes["href"].nodeValue; 
	var win = window.open(url, '_blank');
	win.focus();
}		
		
		
function start_dialog_table_loading(element)
{
	var preloader = $('#' + element).closest(".modal-dialog, [data-menu-tab]").preloader();
	if (preloader)
		preloader.process();
	else $("#common-preloader").addClass('shown process');
}
		
function stop_dialog_table_loading(element)
{
	var preloader = $('#' + element).closest(".modal-dialog, [data-menu-tab]").preloader();
	if (preloader)
		preloader.hide();
	else $("#common-preloader").removeClass('shown process');
}
		
		
		
		
		
		
		
 
		

//===============================================================================
// create_dialog_table
//===============================================================================
function create_dialog_table_n1(obj, element, tableDef)
{	
console.log( 'create_dialog_table_n1 called  '  );

stop_dialog_table_loading(element);

		// On error -> show error message:
		if( !obj.status || obj.error )
			{
				if( msgDefs[obj.msg] ) document.getElementById(element).innerHTML = msgDefs[obj.msg]; else document.getElementById(element).innerHTML = obj.msg;  
				return;
			}
						
					//	console.log('ggggg1: ', obj );
						
	//			// ! Do not modify !
					var rows = obj.return_data;
					var tableData = [];
					for(var i in rows){		var a = [];	 	Object.keys(rows[i]).forEach(function (key) {  a.push( rows[i][key]  ); });	tableData.push( a );	}
			//		var table =  {tabHeadder: Object.keys(  rows[0] ), tabData: tableData  };
						
						
				//		var tabData  = obj.return_data.tabData;
				//		var tabHeadder = obj.return_data.tabHeadder;
				//		console.log('rrrooowww: ', rows );
						
						var tabData  = tableData;
						var tabHeadder = Object.keys(  rows[0] );
						
					//	console.log('tabData: ', tabData );
				//		console.log('tabHeadder: ', tabHeadder );
//
							var cols = [];	
		for(var i in tabHeadder)  
			{	
				cols[i] = {}; 				
				var h = tabHeadder[i];					
				var tde = tableDef[h];
				if( tde == null ) {  cols[i] = null; 	for(var j in tabData ) tabData[ j ][ i ] = [];	continue;}		// remove disabled column
				if(typeof tde !== "object" ){	if( tde ) 	cols[i].sTitle = tde;	else 	cols[i].sTitle = h;	}	
				else 
					{
						cols[i].sTitle = tde.Caption;			
						for(var j in tabData )tabData[ j ][ i ]  =  tde.fun( tabData[ j ][ i ] );
					}
			}
						  
			 
		

		
		element = '#'+element;
		var understock_index = tabHeadder.indexOf('understock');		//		var understock_index = obj.return_data.tabHeadder.indexOf('understock');
		var tconf = {
								dom: 'C<"clear">Blfrtip',
								//sDom: 'l<"H"Rf>t<"F"ip>' ,			// Filter
								//order: [[0, 'asc']],
								buttons: [ 'pageLength',   'colvis',  	{ extend: 'csv', text: 'Export' }	],
								select: {            style: 'single'        },
								responsive: true,
								stateSave: true,
								stateSaveCallback: function(settings,data){ localStorage.setItem( 'DataTables_' + settings.sInstance, JSON.stringify(data) )},
								stateLoadCallback: function(settings){return JSON.parse( localStorage.getItem( 'DataTables_' + settings.sInstance ) )		},
								data: tabData,	//obj.return_data.tabData
								columns: cols,
								aLengthMenu: [	[5, 10, 20, 50, 100, 200, 1000, -1],	[5, 10, 20, 50, 100, 200, 1000, 'All']	],		 
								sPaginationType: 'full_numbers',								
								bLengthChange: false,									//	Hide/Show entries selector						
							 	bAutoWidth: false,
								autoWidth: false,
							//	colReorder: true,
								colReorder: false,
								//	"scrollY":        "200px",						       // Enable scrolling bars
								//	"scrollCollapse": true,
								//	"paging":         false,
								fnRowCallback_disabled: function (nRow, aData, iDisplayIndex, iDisplayIndexFull)
							//	{								
							//		//console.log( iDisplayIndex,  iDisplayIndexFull);									
							//		// Paint  line defferent color:								
							//		if (aData[understock_index] )
							//		{
							//			$(nRow).css('color', 'red').css('font-style', 'italic');
							//		}
							//		$(element+'_filter label input').focus();										// To make the searchbox focused.
							//	},

								{
								
								
								
									for( var i in aData )
										if( typeof aData[i] === 'object'  && aData[i] )
											{	$(nRow).css('color', aData[i].rowColor).css('font-style', 'italic');	aData[i] = aData[i].textValue;	}
								},
								
								
								fnDrawCallback: function () 
								{
                                    if (this.closest('.table-horizontal-scroller').length == 0) 
									{	
                                        this.find('th').each(function (){        this.innerHTML = "<span class='transparent'>" + this.innerHTML + '</span><div data-text="' + this.innerHTML + '"><span></span></div>';             });
                                        var hScroll = $('<div class="table-horizontal-scroller"></div>');
                                        var separator = $('<div class="table-scroll-separator"></div>');
                                        var vScroll = $('<div class="table-vertical-scroller"></div>');
                                        hScroll.insertBefore(this);
                                    this.appendTo(vScroll.appendTo(separator.appendTo(hScroll)));
                                    }									
                                    $(element + '_filter label input').focus();									// To make the searchbox focused.
                                } 	
						};
						
		// If multiple selection enabled:					  
		if( obj.select_by_col )
			{
				cols.unshift( {title: "Select"} );   	
				for(var i in obj.return_data.tabData){	obj.return_data.tabData[i].unshift( '' );			}
				 tconf.columnDefs = [ {			orderable: false,		className: 'select-checkbox',		targets:   0		} ];	// Select a row with checkbox
				 tconf.select = {            style: 'multiple'   , 	selector: 'td:first-child'     };
			}
									  
			   
		// If enabled				
		if(     localStorage.getItem("stock_enable_r_understock_paint")   == 'true' ) tconf.fnRowCallback = tconf.fnRowCallback_disabled;

		var table = $(element).DataTable( tconf );//.rowGrouping({ iGroupingColumnIndex: 2 });;		//.columnFilter(filterconf).bind('sortEnd', function(sorter){	});		
	
		$('div.dataTables_filter input').focus();
		

		
		
		var active_area = $(element +' tbody');
		if( obj.select_by_col )
			{	
				var table = $(element).DataTable( tconf );
			}
		else	
		// On row select event handler LMB CLC and LMB DBL CLC:		
		active_area.on( 'click dblclick', 'tr', function (evt)	
		   { 		
				if ( $(this).hasClass('selected') )$(this).removeClass('selected'); 	else 
					{
						table.$('tr.selected').removeClass('selected');
						$(this).addClass('selected');					
						table.$('tbody').css({'user-select': 'none'});					
						$(this).css({'user-select': 'text'});								
						$(element).data('lastSelectedRow',  table.row( this ).data() );							// pass event to handler
						$(element).data('lastSelectedRow_Head',  obj.return_data.tabHeadder );							// pass event to handler
					}				
			});		
			
 
  
			if(obj.row_dblclick)	    $(element).on('dblclick',  'tbody td', function()
				{				
				//	 console.log('selected_col= ', selected_col)
				//	console.log('value by API : ', table.cell({ row: this.parentNode.rowIndex, column : this.cellIndex }).data() ,    this.cellIndex    );
				//	console.log('coll = ', this.cellIndex ,  '  row = ' , this.parentNode.rowIndex);
				// console.log('row = ', table.row(  this.parentNode.rowIndex  ).data() );
					obj.row_dblclick(
						{		
							col:	this.cellIndex,
							row:	this.parentNode.rowIndex,
							row_data:  table.row( this.parentNode.rowIndex -1 ).data() 
						});					
				});	
			
}
 
//===============================================================================
// Update tag table
//===============================================================================
function update_dialog_table_n1(obj, element, tableDef)
{
 
 stop_dialog_table_loading(element);
 
 
		//if( !obj.return_data)return; 
		// no headder || no data  => empty table
	//	if(!obj.return_data || !obj.return_data.tabHeadder) return;
		if(! tableDef ) return console.log( 'Missing def_table:', tableDef, obj);
  

	var rows = obj.return_data;
					var tableData = [];
					for(var i in rows){		var a = [];	 	Object.keys(rows[i]).forEach(function (key) {  a.push( rows[i][key]  ); });	tableData.push( a );	}
				
		var dialog =  tableData;
		//var dialog =  obj.return_data.tabData;
		var table = $('#'+element).dataTable();
		
		
		//table.clear().draw();
		
		if(! table.fnSettings()) {	console.log('*problem x81, no data-table to update*');	 return;	}
		oSettings = table.fnSettings();				
		table.fnClearTable(this);																					// Clear the table
		for(var i in dialog)	table.oApi._fnAddData(oSettings, dialog[i] );
		table.fnDraw();																								// Re-populate the table
	//	table.draw();																								// Re-populate the table
}
		
	
//===============================================================================
// Updateor Create tag table
//===============================================================================
function dialog_table_n1(obj, element, tableDef)
{
	if(!$.fn.dataTable.isDataTable($('#'+element))) create_dialog_table_n1(obj, element, tableDef);
	else {
			//	$('#'+element).DataTable().clear().draw();
				update_dialog_table_n1(obj, element, tableDef);
			}
}
 
 
		
		
 
		
		 
		
		
		
		
//===============================================================================
// create_dialog_table
//===============================================================================
function create_dialog_table(obj, element, tableDef, onRowDraw, ordering = true, serverSide)
{

 
//console.log( 'create_dialog_table called   by ' , create_dialog_table.caller);
//console.log( 'create_dialog_table called  '  );

//return create_dialog_table(obj, element, tableDef, onRowDraw, ordering = true)
	 var preloader = $('.preloader');
	 var serverRequestTimer;
	preloader.removeClass('shown process');
					 
		element = typeof element == "string" ? document.getElementById(element) : element;
		// On error -> show error message:
		if( !obj.status || obj.error ) { element.innerHTML = obj.msg;  return;}
		

		if( !obj.return_data)return;		
		last_asset_dialog_uid = element.id;				
			
		 
		// Update only if table exists:
		//var u = document.getElementById('gialog_TB_divAAAAA');			
		//if( u.tabIndex >0 )	{ console.log('*');  update_dialog_table( obj );    return; }	
			
		
		//var  context_s = obj.return_data.columns_contextMenu;				// add context menu
		//var  editor_s = obj.return_data.columns_editor;				// edit element
		var  link_s = obj.return_data.columns_link;
		obj.return_data.tabHeadder = tableDef || obj.return_data.tabHeadder;
		
		
		
	//	console.log( obj); return;
		
		
		if(! obj.return_data.tabHeadder ) return console.log( ' Missing obj.return_data.tabHeadder:', obj);
		
		// Formatting the title bar:
		var cols = [];	for(var i = 0; i<obj.return_data.tabHeadder.length; i++)  
			{	
				cols[i] = {}; 
				
				var h = obj.return_data.tabHeadder[i]
			 
				if (h instanceof Object){
					cols[i].title = h.title;
					cols[i].getVal = h.value;
					cols[i].className = h.cssClass;
					cols[i].orderable = h.orderable === true || h.orderable === undefined;
					cols[i].ssSort = h.ssSort;
					cols[i].isAction = h.isAction;
					cols[i].actionList = h.actionList;
					cols[i].actions = {};
				}
				else cols[i].title = h;
				if (!cols[i].isAction)
					cols[i].render = function( i,a,b,c,d )
						{
							//if(obj.return_data.columns_link && obj.return_data.columns_link[i] ){	if( a && a != true) 	return('<a href = "'+ a +'" > link </a>');		}
							//	if(link_s && link_s[i] ){	if( a && a != true) 	return('<a href = "'+ link_s +'" > link </a>');		}
								if(link_s && link_s[i] ){	if( a && a != true) 	return('<button style="width:100%" href = "'+ a +'" title = "'+ a +'" onclick = "linkAtNewTab(this)">Product webpage</button>');		}
						
						if(a !== true)	
							if (cols[i].getVal instanceof Function)		
								try { 
									return cols[i].getVal(c); 
								} 
								catch(e){
									return '';
								}
							else return a;
							
						}.bind(0,i);
				else cols[i].render = function( i,a,b,c,d ){
					var str = '';
					var list = cols[i].actionList;
					var action;
					for (var l in list){
						action = list[l];
						str += `<span class="table-action ${action.cssClass}" data-action="${action.name}"></span>`
						cols[i].actions[action.name] = action.action;
					}
					return str;
				}.bind(0,i);
			}					
		/*
		cols.push( {
                "className":      'details-control',
                "orderable":      false,
                "data":           null,
                "defaultContent": '',
	 	//		"EEE":"Hello world!"
            } );
		*/  
		
		
	 	
	//	var cols = [];	for(var i = 0; i<obj.return_data.tabHeadder.length; i++)  
	//	{
	//	
	//	}
		

		var tconf = {
							//	dom: 'C<"clear">Bfrtip',			// + Show entries selector
								dom: 'C<"clear">Blfrtip',
								buttons: [ 'pageLength', {	extend: 'colvis',    	text: 'Columns'	}],
								ordering,
								//responsive: true,								
								// Save sorting and pagination states:
								stateSave: true,
								stateSaveCallback: function(settings,data){ localStorage.setItem( 'DataTables_' + settings.sInstance, JSON.stringify(data) )},
								stateLoadCallback: function(settings){return JSON.parse( localStorage.getItem( 'DataTables_' + settings.sInstance ) )		},
								data: obj.return_data.tabData,			// ACHTUNG! data as it is. including menus and active elements!								
								columns: cols,
								aLengthMenu: [	[20, 50, 100, 200, 1000, -1],	[20, 50, 100, 200, 1000, 'All']	],		 
								sPaginationType: 'full_numbers',   		//   full_numbers || two_button
							 	bAutoWidth: false,
								autoWidth: false,
								bLengthChange: false,	
						//		colReorder: true,											// DnD
								colReorder: false,											// DnD
								//	"scrollY":        "200px",						       // Enable scrolling bars
								//	"scrollCollapse": true,
								//	"paging":         false,			
								//fnDrawCallback: function(){	$('#'+element+'_filter label input').focus();		},			// To make the searchbox focused.
								fnDrawCallback: function () 
								{
                                    if (this.closest('.table-horizontal-scroller').length == 0) 
									{
                                       // this.find('tr').each(function (){        this.innerHTML = this.innerHTML + '<div data-text="' + this.innerHTML + '"><span></span></div>';             });
										
                                        this.find('th').each(function (){        this.innerHTML = "<span class='transparent'>" + this.innerHTML + '</span><div data-text="' + this.innerHTML + '"><span></span></div>';             });
                                        var hScroll = $('<div class="table-horizontal-scroller"></div>');
                                        var separator = $('<div class="table-scroll-separator"></div>');
                                        var vScroll = $('<div class="table-vertical-scroller"></div>');
                                        hScroll.insertBefore(this);
                                    this.appendTo(vScroll.appendTo(separator.appendTo(hScroll)));
                                    }									
                                    $(element).find('.dataTables_filter input[type="search"]').focus();
                                },
						//		order: [[0, 'asc']],
						//		   sDom: 'l<"H"Rf>t<"F"ip>' ,			// Filter		
						//			"columnDefs": [				{ "visible": true, "targets": 1 }		],
						//			"order": [[ 0, 'asc' ]],
						//			"displayLength": 25,
												
								select: {            style: 'single'        },						
								// Filtering .... ??		
								fnRowCallback: onRowDraw,
								searchDelay: 500,
								serverSide: !!serverSide,
								ajax: !!serverSide ? function(data, callback, settings){
									clearTimeout(serverRequestTimer);
									start_dialog_table_loading(element.id);	
									serverRequestTimer = setTimeout(function(){
										var draw = data.draw;
										var obj = Object.assign({}, serverSide.data, {
											start:  data.start,
											length: data.length,
											search: data.search.value || serverSide.data.search,
											sort:{
												column: data.order[0] ? settings.aoColumns[data.order[0].column].ssSort : undefined,
												direction: data.order[0] ? data.order[0].dir : undefined
											}
										});
										MISO_cmd3(serverSide.api, obj,function (o) {
											if (o.error)
												return callback({draw, data:[], recordsTotal: 0, recordsFiltered: 0, error: o.timeout ? "Request timeout" : o.msg});
											stop_dialog_table_loading(element.id);	
											o.return_data.draw = draw;
											callback(o.return_data);										
										});
									}, 250); 
								} : undefined
						};
 
////// NEED TO SET user-select: text TO EACH ROW 	
//$(row).addClass("label-warning");
 
 
		//var filterconf = {	aoColumns: [ null, null, null, null, { type: "text" }, null  ]		};	
		var table = $(element).DataTable( tconf );//.rowGrouping({ iGroupingColumnIndex: 2 });;		//.columnFilter(filterconf).bind('sortEnd', function(sorter){	});		
		$('div.dataTables_filter input').focus();		
	/*			
		// Menu		
	if(0)	$.contextMenu({
		  		selector:	'#'+element + ' tbody',
				className: 'data-title',
				items: 
					{
						sep1: 'Not',
						test1: {name: "Delete", icon: "background-image: url(icon-delete.png); "},
						sep1: "---------",
						test2: {name: "Edit"},
						sep2: "---------",
						test3: {  name: "Copy",      callback: function(key, opt){            }}
					}
			// ,  icon: function(){    return 'context-menu-icon context-menu-icon-quit';        }			
		}); 
	


	
		// set a title
		$('.data-title').attr('data-menutitle', "Menu >> NOT IMPLEMENTED");
*/		


		var active_area = $(element).find('tbody');		
		
		// On row select event handler LMB CLC and LMB DBL CLC:	
		active_area.on( 'click dblclick', 'tr', function (e)	{ 
		//		if ( $(this).hasClass('selected') )$(this).removeClass('selected'); 
		//		else 
				{	 																			
					table.$('tr.selected').removeClass('selected');
					$(this).addClass('selected');					
					table.$('tbody').css({'user-select': 'none'});					
					$(this).css({'user-select': 'text'});		
					
					$(element).data('lastSelectedRow',  table.row( this ).data() );							// pass event to handler
					$(element).data('lastSelectedRow_Head',  obj.return_data.tabHeadder );							// pass event to handler
				}				
			});	 
		active_area.on( 'click', '[data-action]', function (e)	{
			var column = table.column($(this).closest("td")[0])
			column = column.settings()[0].aoColumns[column.index()];
			var action = column.actions[$(this).attr("data-action")];
			var data = table.row($(this).closest("tr")[0]).data();
			if (typeof action == "string")
				$(element).trigger(action, data);
			else if (typeof action == "function")
				action(data);
		});	 
		
}
	

	

 
//===============================================================================
// Update tag table
//===============================================================================
function update_dialog_table(obj, element)
{
	if( !obj.return_data)return; 
	
	var dialog =  obj.return_data.tabData;
	var table = $('#'+element).dataTable();
	if(! table.fnSettings()) {	console.log('*problem x81, no data-table to update*');	 return;	}
	oSettings = table.fnSettings();				
	table.fnClearTable(this);																					// Clear the table
	for(var i in dialog)	table.oApi._fnAddData(oSettings, dialog[i] );
	table.fnDraw();																								// Re-populate the table
}

 
	
//===============================================================================
// show 'Please wait' message
//===============================================================================
var overlay_BS_waiting_mes = 0;
function cu_conf_dlg_open()
{ 
/*
if( ! document.getElementById("proc_request_ID")  )  $('<div id="proc_request_ID" > Request is being processed... </div>').appendTo('body');
	   $("#proc_request_ID").dialog({
						width:'auto',
						title:  'please wait' ,
						modal: true,
						zIndex: 100000,
						baseZ: 100000,
						autoOpen: true,
					//	buttons: [{       text: "Ok",    click: function() {       $( this ).dialog( "close" );     }   }], 
					}).css("font-size", "15px").css( "z-index","100000");  
*/				
	return;		
	overlay_BS_waiting_mes	= BootstrapDialog.show(
				{	title:  'Request is being processed...' ,
					message:  '<br><br>Please wait<br><br>',
			 		animate: false,
					modal: true,		
				});								
//	overlay_BS_waiting_mes	= BootstrapDialog.alert("wait");
}


//===============================================================================
// hide 'Please wait' message
//===============================================================================
function cu_conf_dlg_close()
{
//	$("#proc_request_ID").dialog('close');
	return;		
overlay_BS_waiting_mes.close();
}


function scan_rfid(id)
{

	rfid_get( 
		function(e)
			{

				document.getElementById(id).value = e;
				document.getElementById(id).click();
				document.getElementById(id).focus();
			});
}

// Not implemented!
function scan_barcode (id)
{
	document.getElementById(id).value = '';
	document.getElementById(id).click();
	document.getElementById(id).focus();
}

// Not implemented!
function scan_qrcode  (id)
{
	alert ("no scanner deteccted");
}


function table_edit_locations( cb )		// EXPERIMENTAL TABLE EDITOR
{
/// если ячейка текст - то простое редактирование если адрес  - то вызываем окно выбора или дропдоунменю
}


function rs_bos_experimental(  sender_elmt_ID, dialog_uid )		// Get slip
{ 		
		// 1. draw form
		// 2. get slipby PO
		// 3. fillthe table ofitems fromslip
		// 4. select items to send tothe storage

			var iid = 0;
				MISO_cmd('on_get_slip', {iid:iid}, 0, function(o)
				{							
					initErrorFuse = o.status;
					if( !MISO_status_display_by_id(o) ) {  alert(  "  Error: " + o.msg);	bsd.close(); return; }
					//asset_id_box.value = o.return_data.S_AssetID;
					//assetproduct_name_box.value = o.return_data.PD_Name;
			 		if(o.return_data.S_Public  === "true") asset_user_public_access_box.value = "true";		else asset_user_public_access_box.value = "false";	
				} );	
				
			var initErrorFuse;
			var dlg = '\
					<div style="height:150%; padding: 1px;  margin: 0px;overflow: auto">\
\
					<br><br>Customer:<br>\
					Cust P.O:  								<input id="asset_po_box" type="text"></input><button>Scan</button><br>\
					Reference NO:          			<input id="asset_refno_box" type="text"></input> <br>\
					Carrier:          							<input id="asset_carr_box" type="text"></input> <br>\
					\
					<br><br>Shipper:<br>\
					Order NO:          						<input id="asset_order_box" type="text"></input><button>Scan</button><br>\
					Cuote NO:          					<input id="asset_catalogue_box" type="text"></input><br>\
\
					</div>';
					
											
		var bsd = BootstrapDialog.show(
						{							
						 	title: 'process a new slip.',										
							message:   dlg,							
							draggable: true,
							closeByBackdrop: false,
							animate: false,
							buttons: 	[												
                                { label: 'Close', cssClass: "dt-button hidden-el danger",	action: function(d){	d.close();	}	},
                                {
                                    id: 'dialog_ok_btn', label: 'OK', cssClass: "dt-button",	action: function(d)
													{
														if(initErrorFuse == false) return;	
														var obj =
																{
															//		iid:									iid,
															//		S_ProductID:					assetproduct_name_box.product_id,						// Must be a custom value -> assetID!
															
																}
																
														//MISO_cmd('on_set_asset', obj, 0, function (o){   if( o.status==false )	alert(  "  Error: " + o.msg);	else {alert(  "  Asset created/updated " ); 	d.close();}	});
														//MISO_cmd('on_get_assets', {top:0}, 0, function(o){  MISO_status_display_by_id(o); update_dialog_table( o, dialog_uid ); 	});
													} }, 
											]					
						});
					
		//	var style = document.createElement('style'); 
			//style.innerHTML = "div.modal-dialog {  width: 50%;   }	";								//opacity: 0.5 ; 
			// document.getElementsByTagName('head')[0].appendChild(style);
} 



 

function setErrorStatusCol( e, c )
{

	//e.classList.remove("green_c");
	//e.classList.remove("red_c");
	//e.classList.remove("form-control-compact");
	//e.style["background-color"] = 'rgba(0, 0, 0, 0)'; 
	
    if (c) var classColor = 'green_c'; else var classColor = 'red_c';
    $(e).removeClass('green_c red_c').addClass(classColor);
	
 
	//Временное решение:
	// brutal patch:

	if( c )e.style["background-color"] = " rgba(22, 255, 0, 0.66)";
	else e.style["background-color"] = "	rgba(215, 10, 30, 40.5) ";
	
	
	if( c )e.style["-webkit-box-shadow"] = " rgba(0, 255, 0, 1.5) 0px 0px 1px ";
	else e.style["background-color"] = "	rgba(255, 40, 50, 1.5) 0px 0px 1px ";
}


